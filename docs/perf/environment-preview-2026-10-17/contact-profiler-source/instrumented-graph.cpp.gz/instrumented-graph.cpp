// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 The Rime Engine Authors.
//
// The render graph compiler + executor (M5.4, ADR-0019). The interesting work is compile():
// declared accesses become dependency edges by RESOURCE VERSIONING, the edges become an
// execution order by a topological sort with a declared-order tiebreak, liveness flows backwards
// from the frame's outputs to cull dead passes, and the per-resource state walk emits exactly
// the barriers the order requires. Everything here runs per frame, on purpose — a frame is data,
// rebuilt as cheaply as it is described (the measured cost lives in the M5.4 proof).

#include "rime/render/render_graph.hpp"
#include "/home/next/reports/rime-reload-environment-2026-10-17/contact-profiler/profile.hpp"

#include <algorithm>
#include <string>

#include "rime/core/diagnostics/assert.hpp"
#include "rime/core/diagnostics/log.hpp"

namespace rime::render {

RenderGraph::~RenderGraph() {
    for (const CachedTexture& c : cache_) {
        device_.destroy(c.handle);
    }
    for (const CachedBuffer& b : buffer_cache_) {
        device_.destroy(b.handle);
    }
    for (const FrameSlot& s : frame_slots_) {
        for (const FrameBlock& b : s.blocks)
            device_.destroy(b.handle);
    }
    for (const FrameBufferPool& p : frame_buffers_) {
        for (const FrameBlock& b : p.buffers) {
            if (b.handle.is_valid())
                device_.destroy(b.handle);
        }
    }
}

namespace {
// The universal uniform-buffer offset alignment. Not queried from the device: every stride in this
// engine already assumes it (the cascade, spot and SDF-compose arrays all use 256), and the RHI
// exposes no alignment query to disagree with. If a device ever needs more, this is the one place.
constexpr std::uint64_t kFrameSliceAlign = 256;

// Each block starts here and every later block is at least this big. 64 KiB holds every uniform a
// frame of the block pushes many times over; the chain exists for correctness, not for the common
// case, and a slot that never needs a second block never allocates one.
constexpr std::uint64_t kFrameBlockBytes = 64 * 1024;

constexpr std::uint32_t kDefaultFrameSlots = 3;
} // namespace

void RenderGraph::set_frames_in_flight(std::uint32_t frames) {
    const std::uint32_t slots = frames + 1; // the swapchain.hpp rule, applied to CPU-written data
    if (slots == frame_slots_.size())
        return;

    // Rebuilding destroys buffers, so this is only legal while nothing is in flight — at
    // construction or before the first frame, which is what the header tells callers.
    for (const FrameSlot& s : frame_slots_) {
        for (const FrameBlock& b : s.blocks)
            device_.destroy(b.handle);
    }
    for (const FrameBufferPool& p : frame_buffers_) {
        for (const FrameBlock& b : p.buffers) {
            if (b.handle.is_valid())
                device_.destroy(b.handle);
        }
    }
    frame_slots_.assign(slots, FrameSlot{});
    frame_buffers_.assign(slots, FrameBufferPool{});
    frame_slot_ = 0;
}

// Both halves of the ring come up together, at the default depth, the first time anything asks.
// Getting this wrong is how `push_frame_buffer` indexed an empty pool: the two containers were
// sized independently, and "they disagree" is not the same condition as "neither exists yet".
void RenderGraph::ensure_frame_ring() {
    const std::size_t slots = frame_slots_.empty() ? kDefaultFrameSlots : frame_slots_.size();
    if (frame_slots_.size() != slots)
        frame_slots_.assign(slots, FrameSlot{});
    if (frame_buffers_.size() != slots)
        frame_buffers_.assign(slots, FrameBufferPool{});
}

rhi::BufferHandle RenderGraph::push_frame_buffer(const void* data, std::size_t bytes) {
    ensure_frame_ring();
    FrameBufferPool& pool = frame_buffers_[frame_slot_];
    if (pool.next >= pool.buffers.size())
        pool.buffers.push_back(FrameBlock{});
    FrameBlock& entry = pool.buffers[pool.next++];
    if (!entry.handle.is_valid() || entry.size < bytes) {
        if (entry.handle.is_valid())
            device_.destroy(entry.handle);
        rhi::BufferDesc bd{};
        bd.size = std::max<std::uint64_t>(bytes, 1);
        bd.usage = rhi::BufferUsage::Uniform | rhi::BufferUsage::Storage | rhi::BufferUsage::Vertex;
        bd.memory = rhi::MemoryUsage::CpuToGpu;
        bd.debug_name = "frame-scratch-buffer";
        entry = FrameBlock{device_.create_buffer(bd), bd.size};
        if (!entry.handle.is_valid()) {
            RIME_ERROR("render: frame-scratch buffer of {} bytes failed", bd.size);
            return {};
        }
    }
    if (bytes > 0)
        device_.write_buffer(entry.handle, data, bytes);
    return entry.handle;
}

RenderGraph::FrameSlice RenderGraph::push_frame_data(const void* data, std::size_t bytes) {
    ensure_frame_ring();
    FrameSlot& slot = frame_slots_[frame_slot_];
    frame_pushed_ += bytes;

    // Take a fresh block when this push does not fit the current one. Deliberately NOT "grow the
    // current block": growing destroys it, and earlier passes this frame already hold slices
    // pointing into it. A block is only ever recycled when the ring comes back to this slot.
    const std::uint64_t need = static_cast<std::uint64_t>(bytes);
    while (slot.block < slot.blocks.size() && slot.offset + need > slot.blocks[slot.block].size) {
        ++slot.block;
        slot.offset = 0;
    }
    if (slot.block >= slot.blocks.size()) {
        rhi::BufferDesc bd{};
        bd.size = std::max(kFrameBlockBytes, need);
        // Uniform, storage and draw-local deformed vertices share the same retirement ring.
        // write_buffer flushes noncoherent host memory before submission; queue submission makes
        // those host writes visible to vertex input as well as shaders. No GPU producer exists
        // here, so a shader/transfer barrier would express the wrong dependency.
        bd.usage = rhi::BufferUsage::Uniform | rhi::BufferUsage::Storage | rhi::BufferUsage::Vertex;
        bd.memory = rhi::MemoryUsage::CpuToGpu;
        bd.debug_name = "frame-scratch";
        const rhi::BufferHandle handle = device_.create_buffer(bd);
        if (!handle.is_valid()) {
            RIME_ERROR("render: frame-scratch allocation of {} bytes failed", bd.size);
            return {};
        }
        slot.blocks.push_back(FrameBlock{handle, bd.size});
        slot.block = slot.blocks.size() - 1;
        slot.offset = 0;
    }

    const FrameBlock& block = slot.blocks[slot.block];
    const std::uint32_t offset = static_cast<std::uint32_t>(slot.offset);
    device_.write_buffer(block.handle, data, bytes, slot.offset);
    // Align the NEXT push, not this one: offset 0 is already aligned, so aligning afterwards keeps
    // the first slice of every block at 0 and never wastes a leading gap.
    slot.offset = (slot.offset + need + kFrameSliceAlign - 1) / kFrameSliceAlign * kFrameSliceAlign;
    return FrameSlice{block.handle, offset, static_cast<std::uint32_t>(bytes)};
}

void RenderGraph::reset() {
    // THE FRAME BOUNDARY, and therefore where the CPU-scratch ring turns over (m17.4). Advancing
    // here rather than at the end of the frame is what makes the slot the previous frame wrote
    // stay untouched while its GPU work is still in flight.
    if (!frame_slots_.empty()) {
        frame_slot_ = (frame_slot_ + 1) % static_cast<std::uint32_t>(frame_slots_.size());
        FrameSlot& slot = frame_slots_[frame_slot_];
        slot.block = 0;
        slot.offset = 0;
        if (frame_slot_ < frame_buffers_.size())
            frame_buffers_[frame_slot_].next = 0;
    }
    frame_pushed_ = 0;

    passes_.clear();
    pass_names_.clear();
    resources_.clear();
    order_.clear();
    timed_passes_ = 0;
    for (CachedTexture& c : cache_) {
        c.in_use = false; // last frame's transients become this frame's free list
    }
    for (CachedBuffer& b : buffer_cache_) {
        b.in_use = false;
    }
}

RGTexture RenderGraph::create_texture(const RGTextureDesc& desc) {
    Resource r;
    r.extent = desc.extent;
    r.format = desc.format;
    r.array_layers = desc.array_layers == 0 ? 1u : desc.array_layers;
    r.array_view = desc.array_view;
    r.debug_name.assign(desc.debug_name);
    resources_.push_back(std::move(r));
    return RGTexture{static_cast<std::uint32_t>(resources_.size() - 1)};
}

RGTexture RenderGraph::import_texture(rhi::TextureHandle handle,
                                      rhi::ResourceState state,
                                      rhi::Extent2D extent,
                                      rhi::Format format,
                                      std::uint32_t array_layers) {
    Resource r;
    r.imported = true;
    r.physical = handle;
    r.state = state;
    r.extent = extent; // needed for the viewport/scissor when a pass renders into this
    r.format = format; // (m10.2's cached shadow array); harmless for a sample-only import
    r.array_layers = array_layers; // >1 → a layered import (per-layer render targets)
    resources_.push_back(std::move(r));
    return RGTexture{static_cast<std::uint32_t>(resources_.size() - 1)};
}

RGBuffer RenderGraph::create_buffer(const RGBufferDesc& desc) {
    Resource r;
    r.kind = ResourceKind::Buffer;
    r.size_bytes = desc.size_bytes;
    r.debug_name.assign(desc.debug_name);
    resources_.push_back(std::move(r));
    return RGBuffer{static_cast<std::uint32_t>(resources_.size() - 1)};
}

RGBuffer RenderGraph::import_buffer(rhi::BufferHandle handle, rhi::ResourceState state) {
    Resource r;
    r.kind = ResourceKind::Buffer;
    r.imported = true;
    r.buffer = handle;
    r.state = state;
    resources_.push_back(std::move(r));
    return RGBuffer{static_cast<std::uint32_t>(resources_.size() - 1)};
}

void RenderGraph::export_texture(RGTexture texture) {
    if (!texture.is_valid() || texture.index >= resources_.size()) {
        RIME_ERROR("render: export_texture with an invalid RGTexture");
        return;
    }
    resources_[texture.index].exported = true;
}

void RenderGraph::export_buffer(RGBuffer buffer) {
    if (!buffer.is_valid() || buffer.index >= resources_.size()) {
        RIME_ERROR("render: export_buffer with an invalid RGBuffer");
        return;
    }
    resources_[buffer.index].exported = true;
}

rhi::TextureHandle RenderGraph::physical(RGTexture texture) const {
    if (!texture.is_valid() || texture.index >= resources_.size()) {
        RIME_ERROR("render: physical() with an invalid RGTexture");
        return {};
    }
    return resources_[texture.index].physical;
}

rhi::BufferHandle RenderGraph::physical_buffer(RGBuffer buffer) const {
    if (!buffer.is_valid() || buffer.index >= resources_.size()) {
        RIME_ERROR("render: physical_buffer() with an invalid RGBuffer");
        return {};
    }
    return resources_[buffer.index].buffer;
}

void RenderGraph::declare_access(std::uint32_t resource, rhi::ResourceState state, bool write) {
    if (resource >= resources_.size()) {
        RIME_ERROR("render: pass '{}' declares an invalid resource handle", passes_.back().name);
        return;
    }
    passes_.back().accesses.push_back({resource, state, write});

    // Usage accumulates from declarations, so a created texture's flags can never disagree with
    // how it is actually used (RGTextureDesc deliberately has no usage field). Buffers need no
    // such accumulation — every declarable buffer access is a storage access.
    Resource& r = resources_[resource];
    if (r.kind == ResourceKind::Buffer) {
        if (state == rhi::ResourceState::IndirectRead)
            r.buffer_usage |= rhi::BufferUsage::Indirect;
        return;
    }
    switch (state) {
        case rhi::ResourceState::ColorTarget:
            r.usage |= rhi::TextureUsage::ColorAttachment;
            break;
        case rhi::ResourceState::DepthTarget:
            r.usage |= rhi::TextureUsage::DepthStencil;
            break;
        case rhi::ResourceState::ShaderRead:
            r.usage |= rhi::TextureUsage::Sampled;
            break;
        case rhi::ResourceState::StorageReadWrite:
            r.usage |= rhi::TextureUsage::Storage;
            break;
        case rhi::ResourceState::TransferSrc:
            r.usage |= rhi::TextureUsage::TransferSrc;
            break;
        case rhi::ResourceState::TransferDst:
            r.usage |= rhi::TextureUsage::TransferDst;
            break;
        default:
            break;
    }
}

void RenderGraph::add_pass_common(std::string_view name,
                                  bool is_raster,
                                  bool fold_repeats,
                                  ExecuteFn fn) {
    // Prefix the identity before the existing uniqueness and fold logic.
    const std::string diagnostic_name = std::string(city_profile::config.prefix) + std::string(name);
    name = diagnostic_name;
    Pass p;
    p.name.assign(name);
    p.is_raster = is_raster;
    p.fold_repeats = fold_repeats;
    p.fn = std::move(fn);

    // A PASS NAME IS AN IDENTITY, NOT A LABEL (m17.3). One system may declare the same pass many
    // times in a frame — a CSM renders the pre-pass once per cascade, local shadows once per
    // invalidated slot — and everything downstream keys on the name: `resolve_timings` reports it,
    // `PerfReport` folds same-named timings into one distribution, and the committed `docs/perf/`
    // JSON writes one object key per pass. Duplicates therefore did not merely read oddly; the
    // 2026-08-30 block baseline contains four `"depth-prepass"` keys, so every ordinary JSON reader
    // keeps one of the four and silently drops 0.32 ms of shadow work.
    //
    // The real fix is upstream — callers now pass names that say what the work is (`csm-cascade-2`)
    // — and this is the backstop that stops the CLASS from coming back the next time a pass is
    // reused. The original linear search restarted at suffix #1 for EACH repeat. Streaming
    // terrain declares 304 identically named passes per view: two views made this cubic search
    // consume ~37 ms in the parent declaration alone. Index exact names and remember each base's
    // first unchecked suffix instead. Names only accumulate until reset(), so an earlier occupied
    // suffix cannot become free: this preserves the original smallest-free-name rule.
    // The declared exception: a caller that set `fold_repeats` is saying the repeat is deliberate
    // and its measurement is the SUM (see ComputePassDesc::fold_repeats). Both sides must agree —
    // folding a repeat onto a pass that did NOT ask for it would merge unrelated work under one
    // key, which is the bug this whole block exists to prevent, so that case still uniquifies.
    const auto [existing, inserted] =
        pass_names_.try_emplace(p.name, PassNameState{fold_repeats, 1});
    if (!inserted && !(fold_repeats && existing->second.fold_repeats)) {
        // Bump until nothing answers to it. Testing the CANDIDATE rather than counting prefix
        // matches is what makes this airtight: counting would hand out `a#1` twice if some caller
        // had already declared a literal `a#1` by hand.
        const std::string base = p.name;
        auto& next_suffix = existing->second.next_suffix;
        for (std::size_t n = next_suffix;; ++n) {
            p.name = base + '#' + std::to_string(n);
            if (!pass_names_.contains(p.name)) {
                next_suffix = n + 1;
                pass_names_.emplace(p.name, PassNameState{fold_repeats, 1});
                break;
            }
        }
    }

    passes_.push_back(std::move(p));
}

void RenderGraph::add_raster_pass(std::string_view name, const RasterPassDesc& desc, ExecuteFn fn) {
    if (desc.colors.empty() && desc.depth == nullptr) {
        RIME_ERROR("render: raster pass '{}' declares no attachments", name);
        return;
    }
    if (desc.colors.size() > rhi::kMaxColorAttachments) {
        RIME_ERROR("render: raster pass '{}' declares {} color targets (max {})",
                   name,
                   desc.colors.size(),
                   rhi::kMaxColorAttachments);
        return;
    }
    add_pass_common(name, true, desc.fold_repeats, std::move(fn));
    Pass& p = passes_.back();
    p.colors.assign(desc.colors.begin(), desc.colors.end());
    if (desc.depth != nullptr) {
        p.has_depth = true;
        p.depth = *desc.depth;
    }

    // Attachments are writes (LoadOp::Load makes them read-modify-write — same edge direction);
    // a read_only depth attachment is genuinely a read, which the dependency builder rewards
    // with weaker ordering (read-after-write instead of write-after-write).
    for (const RGColorAttachment& c : p.colors) {
        declare_access(c.texture.index, rhi::ResourceState::ColorTarget, true);
    }
    if (p.has_depth) {
        declare_access(p.depth.texture.index, rhi::ResourceState::DepthTarget, !p.depth.read_only);
    }
    for (const RGTexture& t : desc.sampled) {
        declare_access(t.index, rhi::ResourceState::ShaderRead, false);
    }
    for (const RGTexture& t : desc.storage) {
        declare_access(t.index, rhi::ResourceState::StorageReadWrite, true);
    }
    // A read-only buffer access is ShaderRead, not StorageReadWrite (m10.3). The distinction is
    // load-bearing rather than cosmetic: the barrier walk emits a transition when the *state*
    // changes, so spelling a read differently from a write is what makes the compute-writes →
    // fragment-reads hazard visible at all.
    for (const RGBuffer& b : desc.buffer_reads) {
        declare_access(b.index, rhi::ResourceState::ShaderRead, false);
    }
    for (const RGBuffer& b : desc.indirect_reads) {
        declare_access(b.index, rhi::ResourceState::IndirectRead, false);
    }
}

void RenderGraph::add_compute_pass(std::string_view name,
                                   const ComputePassDesc& desc,
                                   ExecuteFn fn) {
    add_pass_common(name, false, desc.fold_repeats, std::move(fn));
    passes_.back().externally_visible = desc.externally_visible;
    for (const RGTexture& t : desc.sampled) {
        declare_access(t.index, rhi::ResourceState::ShaderRead, false);
    }
    for (const RGTexture& t : desc.storage_read) {
        declare_access(t.index, rhi::ResourceState::StorageReadWrite, false);
    }
    for (const RGTexture& t : desc.storage_write) {
        declare_access(t.index, rhi::ResourceState::StorageReadWrite, true);
    }
    for (const RGBuffer& b : desc.buffer_reads) {
        declare_access(b.index, rhi::ResourceState::ShaderRead, false);
    }
    for (const RGBuffer& b : desc.buffer_writes) {
        declare_access(b.index, rhi::ResourceState::StorageReadWrite, true);
    }
    for (const RGBuffer& b : desc.indirect_reads) {
        declare_access(b.index, rhi::ResourceState::IndirectRead, false);
    }
}

void RenderGraph::compile() {
    const std::size_t n = passes_.size();

    // ── 1. Dependency edges by resource versioning ────────────────────────────────────────
    // Walk passes in declared order tracking, per resource, who wrote it last and who has read
    // that version. A read depends on the last write (RAW). A write depends on the last write
    // (WAW) *and* on every read of the old version (WAR — the write must not clobber data a
    // reader still needs). This is SSA thinking applied to GPU resources: each write creates a
    // new version, and edges connect versions to their consumers.
    struct ResourceLife {
        std::uint32_t last_writer = kInvalidIndex;
        std::vector<std::uint32_t> readers;
    };

    std::vector<ResourceLife> life(resources_.size());
    std::vector<std::vector<std::uint32_t>> edges(n); // edges[a] = passes that must run after a
    std::vector<std::uint32_t> indegree(n, 0);

    const auto add_edge = [&](std::uint32_t from, std::uint32_t to) {
        if (from == kInvalidIndex || from == to)
            return;
        // Duplicate edges only skew indegree bookkeeping if we count them twice.
        if (std::find(edges[from].begin(), edges[from].end(), to) != edges[from].end())
            return;
        edges[from].push_back(to);
        ++indegree[to];
    };

    for (std::uint32_t pi = 0; pi < n; ++pi) {
        for (const Access& a : passes_[pi].accesses) {
            ResourceLife& rl = life[a.resource];
            if (a.write) {
                add_edge(rl.last_writer, pi);
                for (std::uint32_t reader : rl.readers)
                    add_edge(reader, pi);
                rl.last_writer = pi;
                rl.readers.clear();
            } else {
                add_edge(rl.last_writer, pi);
                rl.readers.push_back(pi);
            }
        }
    }

    // ── 2. Liveness: cull passes that feed no output ──────────────────────────────────────
    // A pass is live iff something the outside world can observe depends on it: it writes an
    // imported or exported resource, or it is explicitly externally visible, or a live pass
    // reads something it writes. A final sampled-only transition of a persistent imported
    // resource affects the state its owner imports next frame; culling it loses that transition.
    // Seed those roots, then let liveness flow backwards along the edges.
    std::vector<bool> live(n, false);
    std::vector<std::uint32_t> worklist;
    for (std::uint32_t pi = 0; pi < n; ++pi) {
        if (passes_[pi].externally_visible) {
            live[pi] = true;
            worklist.push_back(pi);
            continue;
        }
        for (const Access& a : passes_[pi].accesses) {
            const Resource& r = resources_[a.resource];
            if (a.write && (r.imported || r.exported)) {
                live[pi] = true;
                worklist.push_back(pi);
                break;
            }
        }
    }
    // Reverse edges once so "who does pass X depend on" is a lookup.
    std::vector<std::vector<std::uint32_t>> redges(n);
    for (std::uint32_t a = 0; a < n; ++a) {
        for (std::uint32_t b : edges[a])
            redges[b].push_back(a);
    }
    while (!worklist.empty()) {
        const std::uint32_t pi = worklist.back();
        worklist.pop_back();
        for (std::uint32_t dep : redges[pi]) {
            if (!live[dep]) {
                live[dep] = true;
                worklist.push_back(dep);
            }
        }
    }
    for (std::uint32_t pi = 0; pi < n; ++pi)
        passes_[pi].culled = !live[pi];

    // ── 3. Topological order, declared order breaking ties ───────────────────────────────
    // Kahn's algorithm, always taking the READY pass with the lowest declared index. The
    // tiebreak buys two things: determinism (the same declarations always schedule identically —
    // a property tests and humans both lean on) and least-surprise (independent passes run in
    // the order the code declared them). O(n²) ready-scans are irrelevant at dozens of passes.
    order_.clear();
    order_.reserve(n);
    std::vector<bool> emitted(n, false);
    std::vector<std::uint32_t> remaining_indegree = indegree;
    for (std::size_t emitted_count = 0; emitted_count < n;) {
        std::uint32_t pick = kInvalidIndex;
        for (std::uint32_t pi = 0; pi < n; ++pi) {
            if (!emitted[pi] && remaining_indegree[pi] == 0) {
                pick = pi;
                break;
            }
        }
        RIME_ASSERT_MSG(pick != kInvalidIndex,
                        "render graph has a dependency cycle — impossible from spans of "
                        "forward-declared accesses unless a resource is re-written after a read "
                        "of its own output in one pass");
        emitted[pick] = true;
        ++emitted_count;
        for (std::uint32_t next : edges[pick])
            --remaining_indegree[next];
        if (live[pick])
            order_.push_back(pick); // culled passes take part in ordering math, not execution
    }
}

void RenderGraph::assign_physicals() {
    for (Resource& r : resources_) {
        if (r.imported || r.physical.is_valid() || r.buffer.is_valid())
            continue;
        bool used = false; // untouched virtuals (declared, never accessed) get no memory
        for (const std::uint32_t pi : order_) {
            for (const Access& a : passes_[pi].accesses) {
                if (&resources_[a.resource] == &r) {
                    used = true;
                    break;
                }
            }
            if (used)
                break;
        }
        if (!used)
            continue;

        // ── Transient buffers (m10.3): the same cache-or-create dance, keyed by size + usage ──
        if (r.kind == ResourceKind::Buffer) {
            rhi::BufferUsage usage = r.buffer_usage;
            if (r.exported)
                usage |= rhi::BufferUsage::TransferSrc; // exported == someone reads it back
            CachedBuffer* hit = nullptr;
            for (CachedBuffer& c : buffer_cache_) {
                if (!c.in_use && c.size_bytes == r.size_bytes && c.usage == usage) {
                    hit = &c;
                    break;
                }
            }
            if (hit == nullptr) {
                rhi::BufferDesc bd{};
                bd.size = r.size_bytes;
                bd.usage = usage;
                bd.memory = rhi::MemoryUsage::GpuOnly;
                bd.debug_name = r.debug_name;
                const rhi::BufferHandle handle = device_.create_buffer(bd);
                if (!handle.is_valid()) {
                    RIME_ERROR("render: transient buffer allocation failed for '{}'", r.debug_name);
                    continue;
                }
                buffer_cache_.push_back({r.size_bytes, usage, handle, false});
                hit = &buffer_cache_.back();
            }
            hit->in_use = true;
            r.buffer = hit->handle;
            r.state = rhi::ResourceState::Undefined; // recycled — contents are garbage
            continue;
        }

        // Exported textures exist to be consumed outside the graph — a readback copy or a
        // streamer tap — so they get TransferSrc whether or not a pass declared it.
        if (r.exported)
            r.usage |= rhi::TextureUsage::TransferSrc;

        // Cache lookup: first free physical whose (extent, format, usage) matches exactly.
        // Usage is part of the key on purpose — reusing a Sampled-only texture as a color target
        // would need recreation anyway.
        CachedTexture* found = nullptr;
        for (CachedTexture& c : cache_) {
            if (!c.in_use && c.extent.width == r.extent.width &&
                c.extent.height == r.extent.height && c.format == r.format && c.usage == r.usage &&
                c.array_layers == r.array_layers && c.array_view == r.array_view) {
                found = &c;
                break;
            }
        }
        if (found == nullptr) {
            rhi::TextureDesc td{};
            td.extent = r.extent;
            td.format = r.format;
            td.usage = r.usage;
            td.array_layers = r.array_layers; // m10.1: a layered transient (CSM cascade array)
            td.array_view = r.array_view;
            td.debug_name = r.debug_name;
            const rhi::TextureHandle handle = device_.create_texture(td);
            if (!handle.is_valid()) {
                RIME_ERROR("render: transient allocation failed for '{}'", r.debug_name);
                continue;
            }
            cache_.push_back(
                {r.extent, r.format, r.usage, r.array_layers, r.array_view, handle, false});
            found = &cache_.back();
        }
        found->in_use = true;
        r.physical = found->handle;
        r.state = rhi::ResourceState::Undefined; // fresh (or recycled — contents are garbage)
    }
}

void RenderGraph::execute(rhi::CommandBuffer& cmd) {
    auto stage_start = city_profile::Clock::now();
    compile();
    city_profile::stage("compile", stage_start);
    stage_start = city_profile::Clock::now();
    assign_physicals();
    city_profile::stage("assign_physicals", stage_start);
    if (city_profile::active() && !city_profile::config.frames.empty()) {
        auto& row = city_profile::config.frames.back();
        row.executed_passes = order_.size();
        row.overflow = order_.size() > max_timed_passes();
    }

    for (const std::uint32_t pi : order_) {
        Pass& pass = passes_[pi];
        city_profile::PassTimer diagnostic_timer(pass.name);
        cmd.begin_debug_label(pass.name);

        // Timestamp pairs bracket every pass while slots last. A larger frame still executes
        // in full and warns that its timing prefix is incomplete; rendering is never truncated.
        const bool timed = timed_passes_ < max_timed_passes();
        if (timed) {
            cmd.write_timestamp(timed_passes_ * 2);
        } else if (!timing_overflow_warned_) {
            RIME_WARN("render: more than {} passes — timing only the first {}",
                      max_timed_passes(),
                      max_timed_passes());
            timing_overflow_warned_ = true;
        }

        // ── Graph-owned barriers (ADR-0019) ───────────────────────────────────────────────
        // Bring every declared resource into the state this pass needs. Attachment states are
        // deliberately delegated: begin_rendering() already performs tracked, correct attachment
        // transitions — and since M5.6 its REUSED-attachment transitions order against all prior
        // writes, so it genuinely is the write-after-write / read-after-write barrier between
        // passes hitting the same target (the depth pre-pass feeding the forward pass rides
        // exactly that). The graph emits transitions for the cases the implicit path cannot
        // see — sampled/storage reads of textures some earlier pass wrote. One owner per kind of
        // knowledge: frame-global read hazards here, attachment mechanics in the backend.
        for (const Access& a : passes_[pi].accesses) {
            Resource& r = resources_[a.resource];
            if (r.kind == ResourceKind::Buffer) {
                // Buffers have no layout and no implicit-transition path to delegate to, so the
                // rule is "state changed ⇒ dependency" (m10.3) — plus one case a state compare
                // cannot see (M18.4). A buffer is only ever declared StorageReadWrite by a WRITER,
                // so StorageReadWrite -> StorageReadWrite is two consecutive writers: a
                // write-after- write (and, for a pass that also reads what it writes,
                // read-after-write) hazard whose state never changes. The micro rasterizer's clear
                // -> raster -> raster chain is exactly that; without this, nothing orders the
                // second atomic pass after the first on a GPU that overlaps dispatches.
                const bool write_after_write = a.state == rhi::ResourceState::StorageReadWrite &&
                                               r.state == rhi::ResourceState::StorageReadWrite;
                if (r.state != a.state || write_after_write) {
                    cmd.buffer_barrier(r.buffer, r.state, a.state);
                    r.state = a.state;
                }
                continue;
            }
            const bool attachment = a.state == rhi::ResourceState::ColorTarget ||
                                    a.state == rhi::ResourceState::DepthTarget;
            if (attachment) {
                r.state = a.state; // begin_rendering will transition; keep our tracking honest
                continue;
            }
            if (r.state != a.state) {
                cmd.texture_barrier(r.physical, r.state, a.state);
                r.state = a.state;
            }
        }

        if (pass.is_raster) {
            // Build the real RenderingInfo from the baked declaration and open the pass scope —
            // the λ only binds and draws. Viewport/scissor default to the full first target so
            // the overwhelmingly common case writes zero boilerplate.
            std::vector<rhi::ColorAttachment> colors;
            colors.reserve(pass.colors.size());
            for (const RGColorAttachment& c : pass.colors) {
                colors.push_back({resources_[c.texture.index].physical, c.load, c.store, c.clear});
            }
            rhi::RenderingInfo ri{};
            if (colors.size() == 1) {
                ri.color = colors[0];
            } else if (!colors.empty()) {
                ri.colors = colors;
            }
            if (pass.has_depth) {
                rhi::DepthStencilAttachment da{};
                da.target = resources_[pass.depth.texture.index].physical;
                da.load_op = pass.depth.load;
                da.store_op = pass.depth.store;
                da.clear_depth = pass.depth.clear_depth;
                da.clear_stencil = pass.depth.clear_stencil;
                da.layer =
                    pass.depth.layer; // m10.1: render into one cascade of a layered depth target
                ri.depth_stencil = da;
            }
            cmd.begin_rendering(ri);

            const Resource& first = pass.colors.empty() ? resources_[pass.depth.texture.index]
                                                        : resources_[pass.colors[0].texture.index];
            rhi::Viewport vp{};
            vp.width = static_cast<float>(first.extent.width);
            vp.height = static_cast<float>(first.extent.height);
            vp.max_depth = 1.0f;
            cmd.set_viewport(vp);
            rhi::Rect2D sc{};
            sc.width = first.extent.width;
            sc.height = first.extent.height;
            cmd.set_scissor(sc);

            pass.fn(cmd);
            cmd.end_rendering();
        } else {
            pass.fn(cmd); // compute/copy body: bind + dispatch (outside any rendering scope)
        }

        if (timed) {
            cmd.write_timestamp(timed_passes_ * 2 + 1);
            ++timed_passes_;
        }
        cmd.end_debug_label();
    }
    if (city_profile::active() && !city_profile::config.frames.empty())
        city_profile::config.frames.back().timed_passes = timing_plan().timed;
}

RenderGraph::TimingPlan RenderGraph::timing_plan() const {
    TimingPlan plan;
    plan.timed = timed_passes_;
    plan.names.reserve(timed_passes_);
    plan.fold.reserve(timed_passes_);
    std::uint32_t slot = 0;
    for (const std::uint32_t pi : order_) {
        if (slot >= timed_passes_)
            break;
        plan.names.push_back(passes_[pi].name);
        plan.fold.push_back(passes_[pi].fold_repeats ? 1 : 0);
        ++slot;
    }
    return plan;
}

std::vector<RenderGraph::PassTiming> RenderGraph::resolve_timings(rhi::CommandBuffer& cmd) const {
    return resolve_timings(timing_plan(), cmd);
}

std::vector<RenderGraph::PassTiming>
RenderGraph::submit_and_time(rhi::Device& device, std::unique_ptr<rhi::CommandBuffer> cmd) const {
    const rhi::SubmitTicket ticket = device.submit(std::move(cmd));
    std::vector<PassTiming> out;
    if (rhi::CommandBuffer* done = device.wait_and_borrow(ticket))
        out = resolve_timings(*done);
    device.release(ticket); // the step the p1 leak dropped; a no-op on an invalid ticket
    return out;
}

std::vector<RenderGraph::PassTiming> RenderGraph::resolve_timings(const TimingPlan& plan,
                                                                  rhi::CommandBuffer& cmd) {
    std::vector<PassTiming> out;
    if (plan.timed == 0)
        return out;
    std::vector<std::uint64_t> ns(static_cast<std::size_t>(plan.timed) * 2);
    if (!cmd.read_timestamps(ns))
        return out; // device cannot timestamp — documented degrade
    out.reserve(plan.timed);
    for (std::uint32_t timing_slot = 0; timing_slot < plan.names.size(); ++timing_slot) {
        const double ms = static_cast<double>(ns[timing_slot * 2 + 1] - ns[timing_slot * 2]) / 1e6;
        // Fold the declared repeats (m17.3c). Only a pass that ASKED to be folded may add into an
        // earlier entry — anything else already has a unique name, so the linear scan finds
        // nothing and the entry is new. Summing rather than keeping the largest because the
        // question a report answers is "what did this frame spend", and the frame paid for all of
        // them; a folded entry's `count` in the report is still one sample per frame, so the
        // percentile stays a per-frame percentile.
        if (plan.fold[timing_slot] != 0) {
            const std::string& name = plan.names[timing_slot];
            const auto it = std::find_if(
                out.begin(), out.end(), [&name](const PassTiming& t) { return t.name == name; });
            if (it != out.end()) {
                it->gpu_ms += ms;
                continue;
            }
        }
        out.push_back({plan.names[timing_slot], ms});
    }
    return out;
}

} // namespace rime::render
