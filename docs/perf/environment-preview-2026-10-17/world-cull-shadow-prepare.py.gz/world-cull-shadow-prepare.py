#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 The Rime Engine Authors.
"""Prepare (or --compile) an external physics shadow object and city profiler link."""
import argparse
import hashlib
import json
import pathlib
import shlex
import subprocess

REPORT = pathlib.Path(__file__).resolve().parent
SOURCE = pathlib.Path('/home/next/projects/rime/engine/physics/src/world.cpp')
BUILD = pathlib.Path('/home/next/projects/rime/build/release')
PROVENANCE = REPORT / 'cull-profiler/provenance.json'
COPY = REPORT / 'world-cull-shadow.cpp'
OBJECT = REPORT / 'world-cull-shadow.o'
BINARY = REPORT / 'world-cull-shadow-profile_play'
EXPECTED_SOURCE_SHA = '038d9514e2e70e80bab317b0f666ab2a60e8a33f3b1d12af01e6123f6af05baf'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def replace_once(text, old, new):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'expected one source anchor, found {count}: {old[:90]!r}')
    return text.replace(old, new, 1)

def prepare(refresh=False):
    if sha(SOURCE) != EXPECTED_SOURCE_SHA:
        raise RuntimeError('root world.cpp changed; refusing stale shadow source')
    if refresh or not COPY.is_file():
        generate_shadow_source()

    entries = json.loads((BUILD / 'compile_commands.json').read_text())
    matches = [e for e in entries if e['file'] == str(SOURCE)]
    if len(matches) != 1:
        raise RuntimeError(f'expected one world.cpp compile command, got {len(matches)}')
    entry = matches[0]
    cmd = shlex.split(entry['command']) if 'command' in entry else entry['arguments'].copy()
    if cmd.count(str(SOURCE)) != 1 or cmd.count('-o') != 1:
        raise RuntimeError('world.cpp compile command has unexpected shape')
    cmd[cmd.index(str(SOURCE))] = str(COPY)
    cmd[cmd.index('-o') + 1] = str(OBJECT)
    provenance = json.loads(PROVENANCE.read_text())
    link = provenance['link_command'].copy()
    archives = [i for i, token in enumerate(link) if token.endswith('librime_physics.a')]
    if not archives or link.count(str(REPORT / 'cull-profiler/profile_play')) != 1:
        raise RuntimeError('profiler link command has unexpected shape')
    link.insert(archives[0], str(OBJECT))
    link[link.index(str(REPORT / 'cull-profiler/profile_play'))] = str(BINARY)
    link = [('-Wl,--dependency-file=' + str(REPORT / 'world-cull-shadow.link.d'))
            if token.startswith('-Wl,--dependency-file=') else token for token in link]
    return cmd, link

def generate_shadow_source():
    source = SOURCE.read_text()
    source = replace_once(source, '#include <cmath>\n', '#include <cmath>\n#include <cstdio>\n')
    source = replace_once(source,
        '    mutable std::vector<std::uint8_t> plain_tight_valid;\n',
        '    mutable std::vector<std::uint8_t> plain_tight_valid;\n'
        '    mutable std::uint32_t shadow_false_culls = 0; // external diagnostic only\n')
    source = replace_once(source,
        '        if (plain_contact_cull_enabled && !(dt > 0.0f && (ccd[da] != 0 || ccd[db] != 0))) {',
        '        bool shadow_would_reject = false;\n'
        '        Aabb shadow_a{};\n'
        '        Aabb shadow_b{};\n'
        '        if (plain_contact_cull_enabled && !(dt > 0.0f && (ccd[da] != 0 || ccd[db] != 0))) {')
    source = replace_once(source,
        '                    continue;\n                }\n            }\n        }\n\n        Manifold m;',
        '                    shadow_would_reject = true;\n'
        '                    shadow_a = aa;\n'
        '                    shadow_b = bb;\n'
        '                }\n            }\n        }\n\n        Manifold m;')
    anchor = '        if (!touching) {\n            // The exact shapes do not overlap.'
    log = '''        if (shadow_would_reject && touching && shadow_false_culls < 10) {
            ++shadow_false_culls;
            const auto& sa = shape[da];
            const auto& sb = shape[db];
            const auto& pa = position[da];
            const auto& pb = position[db];
            const auto& qa = orientation[da];
            const auto& qb = orientation[db];
            const float gap_x = std::max(shadow_a.min.x - shadow_b.max.x,
                                         shadow_b.min.x - shadow_a.max.x);
            const float gap_y = std::max(shadow_a.min.y - shadow_b.max.y,
                                         shadow_b.min.y - shadow_a.max.y);
            const float gap_z = std::max(shadow_a.min.z - shadow_b.max.z,
                                         shadow_b.min.z - shadow_a.max.z);
            std::fprintf(stderr,
                "[plain-shadow] n=%u world=%.*s dt=%.9g a=%u:%u b=%u:%u "
                "type=%u,%u hull=%u:%u,%u:%u radius=%.9g,%.9g halfheight=%.9g,%.9g "
                "halfA=(%.9g,%.9g,%.9g) halfB=(%.9g,%.9g,%.9g) "
                "posA=(%.9g,%.9g,%.9g) posB=(%.9g,%.9g,%.9g) "
                "quatA=(%.9g,%.9g,%.9g,%.9g) quatB=(%.9g,%.9g,%.9g,%.9g) "
                "aabbA=(%.9g,%.9g,%.9g)-(%.9g,%.9g,%.9g) "
                "aabbB=(%.9g,%.9g,%.9g)-(%.9g,%.9g,%.9g) "
                "gap=(%.9g,%.9g,%.9g) normal=(%.9g,%.9g,%.9g) count=%u "
                "depth=(%.9g,%.9g,%.9g,%.9g)\\n",
                shadow_false_culls, static_cast<int>(zone(StepZone::Step).size()),
                zone(StepZone::Step).data(), dt,
                pr.a.index, pr.a.generation, pr.b.index, pr.b.generation,
                static_cast<unsigned>(sa.type), static_cast<unsigned>(sb.type),
                sa.hull.index, sa.hull.generation, sb.hull.index, sb.hull.generation,
                sa.radius, sb.radius, sa.half_height, sb.half_height,
                sa.half_extents.x, sa.half_extents.y, sa.half_extents.z,
                sb.half_extents.x, sb.half_extents.y, sb.half_extents.z,
                pa.x, pa.y, pa.z, pb.x, pb.y, pb.z,
                qa.x, qa.y, qa.z, qa.w, qb.x, qb.y, qb.z, qb.w,
                shadow_a.min.x, shadow_a.min.y, shadow_a.min.z,
                shadow_a.max.x, shadow_a.max.y, shadow_a.max.z,
                shadow_b.min.x, shadow_b.min.y, shadow_b.min.z,
                shadow_b.max.x, shadow_b.max.y, shadow_b.max.z,
                gap_x, gap_y, gap_z, m.normal.x, m.normal.y, m.normal.z,
                static_cast<unsigned>(m.count), m.points[0].penetration,
                m.points[1].penetration, m.points[2].penetration,
                m.points[3].penetration);
        }
'''
    source = replace_once(source, anchor, log + anchor)
    COPY.write_text(source)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true', help='compile and link after preparing')
    parser.add_argument('--refresh', action='store_true', help='regenerate shadow source from root (overwrites manual edits)')
    args = parser.parse_args()
    compile_command, link_command = prepare(refresh=args.refresh)
    (REPORT / 'world-cull-shadow-commands.json').write_text(json.dumps({
        'source_sha256': sha(SOURCE), 'shadow_sha256': sha(COPY),
        'compile_cwd': str(BUILD), 'compile': compile_command, 'link': link_command,
        'binary': str(BINARY)}, indent=2) + '\n')
    if args.compile:
        with (REPORT / 'world-cull-shadow-build.log').open('w') as log:
            subprocess.run(compile_command, cwd=BUILD, stdout=log, stderr=subprocess.STDOUT, check=True)
            subprocess.run(link_command, cwd=BUILD, stdout=log, stderr=subprocess.STDOUT, check=True)
    print(BINARY)

if __name__ == '__main__':
    main()
