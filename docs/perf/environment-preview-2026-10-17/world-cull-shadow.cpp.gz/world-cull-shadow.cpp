// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 The Rime Engine Authors.
#include "rime/physics/world.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "aabb_tree.hpp"
#include "compound.hpp"
#include "heightfield.hpp"
#include "hull.hpp"
#include "islands.hpp"
#include "narrowphase.hpp"
#include "rime/core/containers/handle.hpp"
#include "rime/core/diagnostics/profile.hpp"
#include "rime/core/hash.hpp"
#include "rime/core/jobs/job_system.hpp"
#include "rime/core/math/quat.hpp"
#include "rime/physics/aabb.hpp"
#include "rime/physics/shape.hpp"
#include "scene_query.hpp"
#include "solver.hpp"

// The M7.1–M7.5 world: a data-oriented body pool, a semi-implicit Euler integrator, a dual
// dynamic-AABB-tree broadphase (M7.2), a GJK/EPA/clipping narrowphase with a persistent warm-start
// cache (M7.3), the sequential-impulse contact solver with its NGS position pass (M7.4), and the
// island partition + sleeping + job-system parallel step (M7.5). One step() runs the whole
// pipeline; it is deterministic to the bit for any worker-thread count (proven by world_hash()).
namespace rime::physics {
namespace {

// 1/x, but 0 for a non-positive x — the "infinite mass/inertia" convention (static/kinematic bodies
// and degenerate shapes get zero inverse mass, so a force produces no acceleration).
[[nodiscard]] float inv_or_zero(float x) noexcept {
    return x > 0.0f ? 1.0f / x : 0.0f;
}

[[nodiscard]] bool is_static(std::uint8_t motion) noexcept {
    return motion == static_cast<std::uint8_t>(MotionType::Static);
}

// Slop on the per-child AABB cull inside a compound pair (M7.12): a child pair is only handed to
// the exact narrowphase if the children's tight bounds overlap within this margin. One millimetre
// comfortably covers the NGS resting slop (5 mm keeps resting shapes genuinely overlapped, so
// this is belt-and-braces against a kissing contact being culled by a rounding ulp) while still
// culling essentially every genuinely separated child pair.
constexpr float kChildCullMargin = 1e-3f;

// The existing compound child cull uses this same 1 mm guard. GJK's contact fast path is at
// 1e-5 m and clipping keeps 1e-5 m, so a truly separated tight AABB pair beyond the guard cannot
// produce an exact manifold. At large world coordinates float ULPs can exceed the guard; fail
// open there rather than making a claim about cancellation in rotated bounds.
[[nodiscard]] bool reliable_tight_bound(const Aabb& b) noexcept {
    const auto finite_small = [](float x) { return std::isfinite(x) && std::fabs(x) <= 512.0f; };
    return finite_small(b.min.x) && finite_small(b.min.y) && finite_small(b.min.z) &&
           finite_small(b.max.x) && finite_small(b.max.y) && finite_small(b.max.z) &&
           b.min.x <= b.max.x && b.min.y <= b.max.y && b.min.z <= b.max.z;
}

using ContactClock = std::chrono::steady_clock;

// A conditional scope keeps all clock reads out of the ordinary contact path. Each scope owns one
// exclusive region; callers place neighbouring scopes around adjacent work, never nest them.
struct ContactTimer {
    bool enabled;
    std::uint64_t& total;
    ContactClock::time_point start;

    ContactTimer(bool on, std::uint64_t& ns) : enabled(on), total(ns) {
        if (enabled) {
            start = ContactClock::now();
        }
    }

    ~ContactTimer() {
        if (enabled) {
            total += static_cast<std::uint64_t>(
                std::chrono::duration_cast<std::chrono::nanoseconds>(ContactClock::now() - start)
                    .count());
        }
    }
};

} // namespace

// The body pool + broadphase. Bodies live in packed, parallel SoA arrays indexed by a *dense* index
// in [0, count); a generational slot table maps a stable BodyId to the current dense index.
// Destroying a body swap-removes it so the arrays stay dense, and bumps the freed slot's generation
// so a stale BodyId is detected. Each body also owns a broadphase proxy in one of two AABB trees: a
// `static_tree` (bodies that never move) and a `dynamic_tree` (dynamic/kinematic). Splitting them
// means the static world is built once and only movers are ever re-inserted — and it makes "both
// static" pairs (which we don't want) impossible by construction.
// The step's profile zones, named once per WORLD rather than once per site (m17.5). A process can
// run more than one PhysicsWorld — `99-the-block` runs a server and a predicting client, and the
// client re-simulates, so it costs roughly twice what the server does — and with one set of names
// `physics.*` is a single distribution over two simulations that are optimised differently. The
// review that opened m17.5 named this as blocking: optimising the merged shape is optimising
// something that belongs to neither world.
//
// Owned as strings because ScopedZone borrows a string_view for the life of the scope and the
// composed name has to outlive it. Built once per label change, never per step.
enum class StepZone : std::uint8_t {
    Step,
    IntegrateVelocity,
    CcdSweep,
    Contacts,
    Constraints,
    Islands,
    Wake,
    Solve,
    Sleep,
    Events,
    Commit,
    Stats,
    Count,
};

constexpr std::string_view kStepZoneSuffix[] = {
    "step",
    "integrate_velocity",
    "ccd_sweep",
    "contacts",
    "constraints",
    "islands",
    "wake",
    "solve",
    "sleep",
    "events",
    "commit",
    "stats",
};
static_assert(std::size(kStepZoneSuffix) == static_cast<std::size_t>(StepZone::Count),
              "every StepZone needs a name, or a zone silently reports as an empty string");

struct PhysicsWorld::Impl {
    struct Slot {
        std::uint32_t dense = core::kInvalidSlotIndex; // kInvalidSlotIndex ⇒ free
        std::uint32_t generation = 0;
    };

    std::vector<Slot> slots; // indexed by BodyId::index
    std::vector<std::uint32_t> free_slots;

    // Dense SoA state (all the same length == body count).
    std::vector<core::Vec3> position;
    std::vector<core::Quat> orientation;
    std::vector<core::Vec3> linear_velocity;
    std::vector<core::Vec3> angular_velocity;
    std::vector<float> inv_mass;         // 0 for static/kinematic
    std::vector<core::Vec3> inv_inertia; // inverse principal moments (M7.4 solver)
    // Rotation from the shape's principal-axis frame to the body frame (M7.11): identity for the
    // primitives, a hull's registration-time eigendecomposition otherwise. Composed with the
    // orientation wherever the inverse inertia is applied (solver.hpp).
    std::vector<core::Quat> inertia_principal;
    // orientation[i] * inertia_principal[i], rebuilt once per step() before the solver view is
    // made (see SolverBodies::inertia_orientation for what it is and is not valid for). Derived
    // scratch: never hashed, never serialised, but kept the same length as its siblings.
    std::vector<core::Quat> inertia_orientation;
    // The materialized I_world⁻¹ per body, filled in the same pass as the composite above and
    // consumed by the velocity phase through SolverBodies::inverse_inertia_world. Derived scratch
    // on exactly the same footing: never hashed, never serialised, world-owned so that two worlds
    // stepping on two threads never share it. Unlike its siblings it is NOT grown at the three
    // body-lifecycle sites — step() sizes it at the top of the pass that fills it, because it
    // carries no value between steps and a push_back there would only be overwritten
    // unconditionally. One `resize` cannot drift out of sync with the pool; three mirrored edits
    // can.
    std::vector<SymMat3> inverse_inertia_world;
    std::vector<std::uint8_t> motion;
    std::vector<float> linear_damping;
    std::vector<float> angular_damping;
    std::vector<float> gravity_factor;
    std::vector<float> friction;      // Coulomb μ (M7.4 solver material)
    std::vector<float> restitution;   // bounciness e (M7.4 solver material)
    std::vector<std::uint8_t> ccd;    // 1 ⇒ continuous collision: speculative contacts (M7.10)
    std::vector<std::uint8_t> sensor; // 1 ⇒ a trigger volume: overlaps reported, no impulse (m15.6)
    std::vector<float> sleep_timer;   // seconds spent below the sleep thresholds (M7.5)
    // The POSE rest route (see islands.hpp): the pose a body was last pinned to, and how long it
    // has stayed inside the envelope around it. Pinned WHOLESALE on every violation and never
    // crept towards the current pose — a creeping anchor would hide exactly the slow drift the
    // envelope exists to catch. Carried at the same three lifecycle sites as sleep_timer and
    // cleared wherever sleep_timer is, because the two are one decision with two routes.
    std::vector<core::Vec3> rest_anchor_position;
    std::vector<core::Quat> rest_anchor_orientation;
    std::vector<float> pose_rest_timer;

    // "This body has to earn sleep again from scratch." Both routes are cleared together and the
    // anchor is re-pinned to where the body is NOW, because every caller is a site that has just
    // made the old anchor a lie (a teleport, an impulse, a wake, a rejoin). A single function so
    // that adding a route later cannot leave one of the six call sites behind.
    void clear_rest(std::size_t d) {
        sleep_timer[d] = 0.0f;
        pose_rest_timer[d] = 0.0f;
        rest_anchor_position[d] = position[d];
        rest_anchor_orientation[d] = orientation[d];
    }

    std::vector<std::uint8_t> asleep; // 1 ⇒ deactivated: skipped by integration + solve (M7.5)
    std::vector<ShapeDesc> shape;     // needed to recompute the world AABB after moving
    std::vector<std::int32_t> proxy;  // this body's node in its broadphase tree
    std::vector<std::uint32_t> dense_to_slot; // dense index → owning slot (for swap-remove fixup)

    core::Vec3 gravity{0.0f, -9.81f, 0.0f};

    // The hull store (M7.11, ADR-0027; unregister added M8.5). Geometry registered once via
    // register_hull, referenced by HullId from bodies' ShapeDescs AND from compound children. The
    // store is now a GENERATIONAL SLOT table (mirroring the body slots above): a freed slot bumps
    // its generation so stale ids read dead, and register_hull reuses freed slots LIFO so ids stay
    // a pure function of the call sequence (determinism). `hull_refs[i]` counts live references
    // (bodies + compound children); unregister_hull refuses while it is non-zero —
    // reject-if-referenced, so a hull a live body or compound names can never be pulled out from
    // under it (which is exactly why compound_child_hull can resolve by index alone). Parallel
    // arrays keep `hulls` contiguous for the hot-path span the narrowphase takes.
    std::vector<ConvexHull> hulls;
    std::vector<std::uint32_t> hull_generation; // per slot; bumped on unregister
    std::vector<std::uint8_t> hull_live;        // 1 = registered, 0 = freed slot awaiting reuse
    std::vector<std::uint32_t> hull_refs;       // live references (bodies + compound children)
    std::vector<std::uint32_t> hull_free_list;  // freed slots, LIFO — deterministic reuse

    // The compound store (M7.12, ADR-0028; unregister added M8.5): the same generational-slot
    // contract as the hull store. `compound_refs[i]` counts live BODIES using compound i (a
    // compound never nests another in v1); unregister_compound refuses while non-zero and, when it
    // does free a compound, releases that compound's reference on each of its child hulls.
    std::vector<CompoundShape> compounds;
    std::vector<std::uint32_t> compound_generation;
    std::vector<std::uint8_t> compound_live;
    std::vector<std::uint32_t> compound_refs;
    std::vector<std::uint32_t> compound_free_list;

    // The heightfield store (M19.1): the same generational-slot contract again. `heightfield_refs`
    // counts live bodies using each tile; unregister refuses while it is non-zero.
    std::vector<HeightfieldShape> heightfields;
    std::vector<std::uint32_t> heightfield_generation;
    std::vector<std::uint8_t> heightfield_live;
    std::vector<std::uint32_t> heightfield_refs;
    std::vector<std::uint32_t> heightfield_free_list;

    // Terrain fallback counters (WorldStats docs). The per-tick pair are written by the contact
    // build (sequential — it never runs on a worker) and copied into last_stats; the query-skip
    // total is cumulative and ATOMIC because queries are const and may be issued from several
    // jobs at once between steps.
    mutable std::uint32_t hf_patch_merges_last = 0;
    mutable std::uint32_t hf_ccd_skipped_last = 0;
    mutable std::atomic<std::uint64_t> hf_query_skips{0};

    AabbTree static_tree;
    AabbTree dynamic_tree;

    // Islands + the parallel step (M7.5). `jobs` is a BORROWED job system (the engine owns it; null
    // ⇒ solve islands sequentially — same result). `islands` is the reusable CSR partition rebuilt
    // each step; its size is one of the witnesses recorded into `last_stats` below (M7.13).
    // `sleeping_enabled` gates deactivation (on by default). None of this is touched concurrently:
    // only the per-island solve runs on worker threads, and islands share no dynamic body.
    core::JobSystem* jobs = nullptr;
    bool sleeping_enabled = true;
    IslandSet islands;

    // This world's profile-zone names (see StepZone). Unlabelled worlds keep the original
    // `physics.<stage>` names, so every existing sample, test and committed baseline is unaffected
    // — only a caller that asks for a label pays the rename.
    std::array<std::string, static_cast<std::size_t>(StepZone::Count)> zone_names;

    void set_zone_label(std::string_view label) {
        for (std::size_t i = 0; i < zone_names.size(); ++i) {
            std::string name = "physics.";
            if (!label.empty()) {
                name += label;
                name += '.';
            }
            name += kStepZoneSuffix[i];
            zone_names[i] = std::move(name);
        }
    }

    [[nodiscard]] std::string_view zone(StepZone z) const noexcept {
        return zone_names[static_cast<std::size_t>(z)];
    }

    // How many islands the last step() handed to `jobs`; 0 when it solved them itself. The witness
    // that the parallel path was actually taken — see WorldStats::islands_solved_parallel.
    std::uint32_t parallel_islands_last = 0;

    // Per-island solve timing (set_island_profile_enabled). OFF by default and then untouched: the
    // step() never reads the clock and never touches these buffers. One cache line per slot so two
    // workers finishing neighbouring islands do not false-share a line and perturb the very times
    // being measured; each island writes ONLY its own slot, so no lock or atomic is needed.
    struct alignas(64) SolveSlot {
        std::uint64_t ns = 0;
        std::uint64_t warm_ns = 0;
        std::uint64_t velocity_ns = 0;
        std::uint64_t store_ns = 0;
        std::uint64_t position_ns = 0;
    };

    bool island_profile_enabled = false;
    std::vector<SolveSlot> island_solve_slots;   // sized island_count per profiled step
    std::vector<IslandSolveCost> island_profile; // the published entries (active islands)
    // The previous profiled step's biggest active island: body count + membership hash.
    bool prev_largest_valid = false;
    std::uint32_t prev_largest_bodies = 0;
    std::uint64_t prev_largest_hash = 0;

    // The most recent step()'s instrument panel (M7.13, WorldStats). Populated in the sequential
    // tail as a pure read of the just-computed tick — so, like the event emission, it never touches
    // body state and never perturbs the world hash. islands_last() and contacts_warm_started_last()
    // read straight out of here (the numbers they always returned are now fields of one struct).
    WorldStats last_stats{};

    // Persistent contact cache (M7.3): last tick's manifolds keyed by contact REGION — the
    // canonical pair id plus, since M7.12, the compound child sub-pair (0 for plain pairs, whose
    // behaviour is unchanged) — so a surviving contact's accumulated impulses carry forward by
    // matching feature id (warm starting). Ordering matters (M7.4): step() commits this cache
    // from the manifolds AFTER the velocity solve wrote its converged impulses into them —
    // committing pre-solve manifolds would persist last tick's warm-start copies forever and the
    // solver would always start cold. The solverless public compute_contacts() commits what it
    // warm-started (zeros on a fresh world), which keeps the narrowphase tests' cache semantics
    // unchanged. `warm_started_last` records the last contact build's feature-id match count —
    // the narrowphase test's witness, and from M7.4 the warm-start hit rate.
    mutable std::unordered_map<ContactCacheKey, ManifoldCacheEntry, ContactCacheKeyHash>
        contact_cache;
    mutable std::uint32_t warm_started_last = 0;
    // The last contact build's broadphase candidate-pair count (M7.13 stats). Set alongside
    // warm_started_last in build_contacts, so both the step() and compute_contacts() paths keep it
    // current; step()'s tail copies it into last_stats.broadphase_pairs.
    mutable std::uint32_t broadphase_pairs_last = 0;
    bool contact_profile_enabled = false;
    mutable ContactProfile contact_profile_last{};
    bool plain_contact_cull_enabled = false;
    mutable std::vector<Aabb> plain_tight_bounds;
    mutable std::vector<std::uint8_t> plain_tight_valid;
    mutable std::uint32_t shadow_false_culls = 0; // external diagnostic only

    // Simulation events (M7.9, events.hpp). step() emits contact and sleep events as a pure READ of
    // the just-solved state, in the sequential tail — so events never write body state, never
    // perturb the world hash, and stay clear of the parallel solve (TSan). Both are
    // DOUBLE-BUFFERED: the tick fills the `_back` buffer, then swaps it to `_front`, so the public
    // accessors expose a stable snapshot of the completed tick until the next step().
    std::vector<ContactEvent> contact_events_front;
    std::vector<ContactEvent> contact_events_back;
    // Triggers get their own pair of buffers, not a flag on ContactEvent: a trigger has no point,
    // no normal and no impulse, and a consumer iterating contacts must not have to skip records
    // whose numeric fields are all meaningless (m15.6).
    std::vector<TriggerEvent> trigger_events_front;
    std::vector<TriggerEvent> trigger_events_back;
    std::vector<SleepEvent> sleep_events_front;
    std::vector<SleepEvent> sleep_events_back;

    // The began/persisted/ended witness: one record per contact REGION (pair + child sub-pair
    // since M7.12; one region per pair for plain bodies), keyed by (broadphase pair key, packed
    // child indices) and kept ASCENDING lexicographically by that key (manifolds already arrive
    // canonically ordered — pairs ascending, child sub-pairs ascending within a pair — so `cur`
    // is built sorted). A single linear merge of this tick's `cur` against last tick's `prev`
    // classifies every region and emits in canonical order — no hash map, no per-tick sort. The
    // two vectors are swapped each tick, reusing their capacity. Owning our own record (rather
    // than reading the warm-start cache) keeps the event lifecycle independent of the solver's
    // cache and lets an Ended event carry the region's last point/normal, which the cache does
    // not store.
    struct ContactRecord {
        std::uint64_t key = 0;      // (a.index << 32) | b.index
        std::uint32_t children = 0; // (child_a << 16) | child_b — the region within the pair
        std::uint32_t patch = 0;    // Manifold::patch — the terrain patch within that (M19.1)
        BodyId a;
        BodyId b;
        core::Vec3 point{0.0f, 0.0f, 0.0f};
        core::Vec3 normal{0.0f, 1.0f, 0.0f};
        float normal_impulse = 0.0f; // summed over the manifold; meaningful for `cur` only
        float tangent_impulse = 0.0f;
        bool suppressed = false; // has a dynamic member but every one is asleep — present, no event
        // A sensor participant (m15.6): reported as a trigger rather than a contact. The flag
        // rides the record so ONE key-sorted merge classifies both families — a trigger's
        // enter/stay/exit is the identical began/persisted/ended computation, and duplicating it
        // would be two lifecycles to keep in agreement.
        bool trigger = false;
    };

    std::vector<ContactRecord> contact_cur;
    std::vector<ContactRecord> contact_prev;

    // Per-step scratch: `asleep` copied at the top of step(), diffed at the tail to find the tick's
    // sleep/wake transitions. Dense-indexed and stable through a step (no create/destroy mid-step).
    std::vector<std::uint8_t> asleep_snapshot;

    [[nodiscard]] std::size_t count() const noexcept { return position.size(); }

    // The collision half of a tick, shared by step() and the public compute_contacts() (defined
    // below, after the struct). Split in two so step() can run the solver in between: build the
    // warm-started manifolds, solve (mutating their impulses), then commit the cache from the
    // SOLVED manifolds.
    void compute_pairs(std::vector<Pair>& out, bool profile = false) const;
    // `dt` > 0 enables M7.10 speculative CCD contacts for opted-in bodies; dt == 0 (the default,
    // used by the compute_contacts() inspection seam) builds only exact overlaps, unchanged from
    // M7.3.
    void build_contacts(std::vector<Manifold>& out, float dt = 0.0f) const;
    // The compound arm of build_contacts (M7.12): one pair whose side(s) are compounds, expanded
    // into child-vs-child sub-pairs, emitting one manifold per touching child pair. Defined below
    // beside build_contacts.
    void build_compound_contacts(const Pair& pr,
                                 std::uint32_t da,
                                 std::uint32_t db,
                                 const CompoundShape* comp_a,
                                 const CompoundShape* comp_b,
                                 float dt,
                                 std::vector<Manifold>& out,
                                 std::uint32_t& warm) const;
    // The terrain arm of build_contacts (M19.1): one body (or each compound child of it) against
    // one heightfield, fanned out into per-patch manifolds. Defined beside build_contacts.
    void build_heightfield_contacts(const Pair& pr,
                                    std::uint32_t da,
                                    std::uint32_t db,
                                    float dt,
                                    std::vector<Manifold>& out,
                                    std::uint32_t& warm) const;
    void commit_contact_cache(const std::vector<Manifold>& manifolds) const;

    [[nodiscard]] AabbTree& tree_for(std::uint8_t m) noexcept {
        return is_static(m) ? static_tree : dynamic_tree;
    }

    [[nodiscard]] const AabbTree& tree_for(std::uint8_t m) const noexcept {
        return is_static(m) ? static_tree : dynamic_tree;
    }

    // Resolve a BodyId to its dense index, or kInvalidSlotIndex if the id is stale/unknown.
    [[nodiscard]] std::uint32_t dense_of(BodyId id) const noexcept {
        if (id.index >= slots.size()) {
            return core::kInvalidSlotIndex;
        }
        const Slot& s = slots[id.index];
        if (s.generation != id.generation || s.dense == core::kInvalidSlotIndex) {
            return core::kInvalidSlotIndex;
        }
        return s.dense;
    }

    // Does `filter` name this broadphase slot as the body to pretend is not there (m12.2)? Called
    // once per candidate leaf by every query's per-body test, which is why it is two integer
    // compares and no branch on tree identity.
    //
    // The generation is part of the comparison on purpose: a QueryFilter carrying an id whose body
    // has since been destroyed must exclude NOTHING, not whatever body happened to move into that
    // slot afterwards. Matching on the index alone would turn a stale self-id into a silent,
    // wandering hole in every query — the kind of bug that shows up as one crate in a hundred being
    // invisible to hitscan.
    // SENSORS ARE EXCLUDED BY DEFAULT, which is the other half of what m15.6b started. A sensor is
    // a body the solver refuses to push against — that is what `Collider::sensor` buys — but until
    // this check the QUERY layer had never heard of the flag, so a trigger volume was a trigger to
    // the solver and a SOLID WALL to every raycast, shape_cast, penetration and overlap_sphere.
    // Tick `sensor` on a doorway volume to detect the player walking through it (exactly the case
    // #165 fixed at the event stage) and the player bonks into an invisible box, can never enter
    // it, and shots stop at its face. Default true rather than false: a trigger is scenery to a
    // bullet and to a footstep, and every existing call site wants that without being edited.
    [[nodiscard]] bool is_excluded(const QueryFilter& f, std::uint32_t slot) const noexcept {
        if (f.exclude.index == slot && f.exclude.generation == slots[slot].generation) {
            return true;
        }
        return !f.sensors && sensor[slots[slot].dense] != 0;
    }

    // Resolve a shape's hull reference to its store entry — nullptr for primitives and for an
    // unresolvable id (null/foreign/stale/unregistered). The generation must match the slot's
    // current one and the slot must be live (M8.5 — a freed-then-reused slot has a bumped
    // generation, so an id from before the free reads dead). This is the ONE place a HullId turns
    // into geometry; everything under the seam takes the pointer from here (ADR-0027).
    [[nodiscard]] const ConvexHull* hull_of(const ShapeDesc& s) const noexcept {
        if (s.type != ShapeType::ConvexHull) {
            return nullptr;
        }
        if (s.hull.index >= hulls.size() || hull_generation[s.hull.index] != s.hull.generation ||
            hull_live[s.hull.index] == 0) {
            return nullptr;
        }
        return &hulls[s.hull.index];
    }

    // Resolve a shape's compound reference — hull_of's twin for the compound store (ADR-0028).
    [[nodiscard]] const CompoundShape* compound_of(const ShapeDesc& s) const noexcept {
        if (s.type != ShapeType::Compound) {
            return nullptr;
        }
        if (s.compound.index >= compounds.size() ||
            compound_generation[s.compound.index] != s.compound.generation ||
            compound_live[s.compound.index] == 0) {
            return nullptr;
        }
        return &compounds[s.compound.index];
    }

    // Resolve a shape's heightfield reference — hull_of's twin for the terrain store (M19.1).
    [[nodiscard]] const HeightfieldShape* heightfield_of(const ShapeDesc& s) const noexcept {
        if (s.type != ShapeType::Heightfield) {
            return nullptr;
        }
        if (s.heightfield.index >= heightfields.size() ||
            heightfield_generation[s.heightfield.index] != s.heightfield.generation ||
            heightfield_live[s.heightfield.index] == 0) {
            return nullptr;
        }
        return &heightfields[s.heightfield.index];
    }

    // The hull store as a span — the form the compound helpers take (compound.hpp stays free of
    // world internals; a compound's hull children resolve against exactly this store).
    [[nodiscard]] std::span<const ConvexHull> hull_span() const noexcept {
        return {hulls.data(), hulls.size()};
    }

    // Tight world AABB of a posed shape, store-aware: the shape-only compute_aabb (aabb.hpp)
    // cannot see the stores, so hull bounds come from posing the stored vertices and compound
    // bounds from the union of the posed children (the ONE broadphase bound a compound owns —
    // model A of ADR-0028 keeps proxy↔body strictly 1:1).
    [[nodiscard]] Aabb
    aabb_of(const ShapeDesc& s, core::Vec3 pos, const core::Quat& q) const noexcept {
        if (const CompoundShape* c = compound_of(s); c != nullptr) {
            return compound_world_aabb(*c, hull_span(), pos, q);
        }
        if (const HeightfieldShape* hf = heightfield_of(s); hf != nullptr) {
            return heightfield_world_aabb(*hf, pos, q);
        }
        const ConvexHull* h = hull_of(s);
        return h != nullptr ? hull_world_aabb(*h, pos, q) : compute_aabb(s, pos, q);
    }
};

void PhysicsWorld::Impl::compute_pairs(std::vector<Pair>& out, bool profile) const {
    out.clear();

    // Every non-static body is a "mover": query both trees with its fat box. A pair (a,b) is packed
    // as (min_slot << 32 | max_slot) — a key that sorts by (a,b) — so sorting then de-duplicating
    // yields the canonical, deterministic pair set. Dynamic–dynamic pairs are found twice (each end
    // queries) and collapse to one; both-static pairs never appear because static bodies never
    // query.
    std::vector<std::uint64_t> keys;
    const std::size_t n = count();
    {
        ContactTimer query_time(profile, contact_profile_last.pair_query_ns);
        for (std::size_t i = 0; i < n; ++i) {
            if (is_static(motion[i])) {
                continue;
            }
            const std::uint32_t self = dense_to_slot[i];
            const Aabb& fat = dynamic_tree.proxy_aabb(proxy[i]);
            const auto add = [&](std::uint32_t other) {
                if (other == self) {
                    return;
                }
                const std::uint32_t a = std::min(self, other);
                const std::uint32_t b = std::max(self, other);
                keys.push_back((static_cast<std::uint64_t>(a) << 32) | b);
            };
            dynamic_tree.query(fat, add);
            static_tree.query(fat, add);
        }
    }

    if (profile) {
        contact_profile_last.raw_candidate_keys = keys.size();
    }

    {
        ContactTimer canonical_time(profile, contact_profile_last.pair_canonicalize_ns);
        std::sort(keys.begin(), keys.end());
        keys.erase(std::unique(keys.begin(), keys.end()), keys.end());

        out.reserve(keys.size());
        for (const std::uint64_t key : keys) {
            const auto a = static_cast<std::uint32_t>(key >> 32);
            const auto b = static_cast<std::uint32_t>(key & 0xFFFFFFFFu);
            out.push_back(Pair{BodyId{a, slots[a].generation}, BodyId{b, slots[b].generation}});
        }
    }
    if (profile) {
        contact_profile_last.unique_pairs = out.size();
        contact_profile_last.duplicate_keys =
            contact_profile_last.raw_candidate_keys - contact_profile_last.unique_pairs;
    }
}

void PhysicsWorld::Impl::build_contacts(std::vector<Manifold>& out, float dt) const {
    out.clear();
    contact_profile_last = {};
    if (plain_contact_cull_enabled) {
        // Dense indices and poses may have changed since the preceding build. Reuse storage, but
        // never a cached bound: even compute_contacts() may follow a teleport or slot recycle.
        plain_tight_bounds.resize(count());
        plain_tight_valid.resize(count());
        std::fill(plain_tight_valid.begin(), plain_tight_valid.end(), std::uint8_t{0});
    }

    // Broadphase first: the candidate pairs are canonical (a.index < b.index), deterministically
    // sorted, and already exclude both-static pairs. A fat-AABB overlap is only a *candidate* — the
    // narrowphase below confirms (or rejects) each with exact geometry.
    std::vector<Pair> pairs;
    compute_pairs(pairs, contact_profile_enabled);
    broadphase_pairs_last = static_cast<std::uint32_t>(pairs.size());

    std::uint32_t warm = 0;
    hf_patch_merges_last = 0;
    hf_ccd_skipped_last = 0;
    for (const Pair& pr : pairs) {
        const std::uint32_t da = dense_of(pr.a);
        const std::uint32_t db = dense_of(pr.b);
        if (da == core::kInvalidSlotIndex || db == core::kInvalidSlotIndex) {
            continue; // impossible for a pair compute_pairs just returned, but stay defensive
        }

        // Terrain first (M19.1): a heightfield is not convex, so neither the plain dispatch nor
        // the compound expansion below can take it. Two heightfields never pair (both static).
        if (shape[da].type == ShapeType::Heightfield || shape[db].type == ShapeType::Heightfield) {
            if (contact_profile_enabled) {
                ++contact_profile_last.heightfield_pairs;
            }
            ContactTimer terrain_time(contact_profile_enabled, contact_profile_last.heightfield_ns);
            build_heightfield_contacts(pr, da, db, dt, out, warm);
            continue;
        }

        // A pair with a compound on either side expands into child-vs-child sub-pairs and may
        // emit SEVERAL manifolds — one per touching child pair (M7.12, ADR-0028). Split off so
        // the plain-pair path below stays byte-for-byte what it was through M7.11.
        const CompoundShape* comp_a = compound_of(shape[da]);
        const CompoundShape* comp_b = compound_of(shape[db]);
        if (comp_a != nullptr || comp_b != nullptr) {
            if (contact_profile_enabled) {
                ++contact_profile_last.compound_pairs;
            }
            build_compound_contacts(pr, da, db, comp_a, comp_b, dt, out, warm);
            continue;
        }

        if (contact_profile_enabled) {
            ++contact_profile_last.plain_pairs;
        }

        bool shadow_would_reject = false;
        Aabb shadow_a{};
        Aabb shadow_b{};
        if (plain_contact_cull_enabled && !(dt > 0.0f && (ccd[da] != 0 || ccd[db] != 0))) {
            const auto tight_bound = [&](std::uint32_t dense) -> const Aabb& {
                if (plain_tight_valid[dense] == 0) {
                    plain_tight_bounds[dense] =
                        aabb_of(shape[dense], position[dense], orientation[dense]);
                    plain_tight_valid[dense] = 1;
                }
                return plain_tight_bounds[dense];
            };
            const Aabb& aa = tight_bound(da);
            const Aabb& bb = tight_bound(db);
            if (reliable_tight_bound(aa) && reliable_tight_bound(bb)) {
                if (contact_profile_enabled) {
                    ++contact_profile_last.plain_tight_tests;
                }
                if (!overlaps(expanded(aa, kChildCullMargin), bb)) {
                    if (contact_profile_enabled) {
                        ++contact_profile_last.plain_tight_rejections;
                    }
                    shadow_would_reject = true;
                    shadow_a = aa;
                    shadow_b = bb;
                }
            }
        }

        Manifold m;
        m.a = pr.a;
        m.b = pr.b;
        // collide_shapes canonicalizes by ShapeType internally and flips the normal to match, so
        // passing the bodies in slot order yields a normal oriented from a toward b (contact.hpp).
        // Hull ids resolve to store pointers HERE — below the seam, above the dispatch (ADR-0027).
        const ConvexHull* ha = hull_of(shape[da]);
        const ConvexHull* hb = hull_of(shape[db]);
        bool touching;
        {
            ContactTimer narrow_time(contact_profile_enabled, contact_profile_last.plain_exact_ns);
            if (contact_profile_enabled) {
                ++contact_profile_last.exact_narrowphase_calls;
            }
            touching = collide_shapes(shape[da],
                                      position[da],
                                      orientation[da],
                                      shape[db],
                                      position[db],
                                      orientation[db],
                                      m,
                                      ha,
                                      hb) &&
                       m.count != 0;
        }
        if (shadow_would_reject && touching && shadow_false_culls < 10) {
            ++shadow_false_culls;
            const auto& sa = shape[da];
            const auto& sb = shape[db];
            const auto& pa = position[da];
            const auto& pb = position[db];
            const auto& qa = orientation[da];
            const auto& qb = orientation[db];
            const float gap_x = std::max(shadow_a.min.x - shadow_b.max.x,
                                         shadow_b.min.x - shadow_a.max.x);
            const float gap_y = std::max(shadow_a.min.y - shadow_b.max.y,
                                         shadow_b.min.y - shadow_a.max.y);
            const float gap_z = std::max(shadow_a.min.z - shadow_b.max.z,
                                         shadow_b.min.z - shadow_a.max.z);
            std::fprintf(stderr,
                "[plain-shadow] n=%u world=%.*s dt=%.9g a=%u:%u b=%u:%u "
                "type=%u,%u hull=%u:%u,%u:%u radius=%.9g,%.9g halfheight=%.9g,%.9g "
                "halfA=(%.9g,%.9g,%.9g) halfB=(%.9g,%.9g,%.9g) "
                "posA=(%.9g,%.9g,%.9g) posB=(%.9g,%.9g,%.9g) "
                "quatA=(%.9g,%.9g,%.9g,%.9g) quatB=(%.9g,%.9g,%.9g,%.9g) "
                "aabbA=(%.9g,%.9g,%.9g)-(%.9g,%.9g,%.9g) "
                "aabbB=(%.9g,%.9g,%.9g)-(%.9g,%.9g,%.9g) "
                "gap=(%.9g,%.9g,%.9g) normal=(%.9g,%.9g,%.9g) count=%u "
                "depth=(%.9g,%.9g,%.9g,%.9g)\n",
                shadow_false_culls, static_cast<int>(zone(StepZone::Step).size()),
                zone(StepZone::Step).data(), dt,
                pr.a.index, pr.a.generation, pr.b.index, pr.b.generation,
                static_cast<unsigned>(sa.type), static_cast<unsigned>(sb.type),
                sa.hull.index, sa.hull.generation, sb.hull.index, sb.hull.generation,
                sa.radius, sb.radius, sa.half_height, sb.half_height,
                sa.half_extents.x, sa.half_extents.y, sa.half_extents.z,
                sb.half_extents.x, sb.half_extents.y, sb.half_extents.z,
                pa.x, pa.y, pa.z, pb.x, pb.y, pb.z,
                qa.x, qa.y, qa.z, qa.w, qb.x, qb.y, qb.z, qb.w,
                shadow_a.min.x, shadow_a.min.y, shadow_a.min.z,
                shadow_a.max.x, shadow_a.max.y, shadow_a.max.z,
                shadow_b.min.x, shadow_b.min.y, shadow_b.min.z,
                shadow_b.max.x, shadow_b.max.y, shadow_b.max.z,
                gap_x, gap_y, gap_z, m.normal.x, m.normal.y, m.normal.z,
                static_cast<unsigned>(m.count), m.points[0].penetration,
                m.points[1].penetration, m.points[2].penetration,
                m.points[3].penetration);
            if (shadow_false_culls == 1 && ha && hb) {
                const auto dump_hull = [&](const char* side, const ConvexHull& hull,
                                           std::uint32_t hull_index,
                                           std::uint32_t hull_generation) {
                    std::string line = "[plain-shadow-hull] {\"world\":\"";
                    const auto world_name = zone(StepZone::Step);
                    line.append(world_name.data(), world_name.size());
                    line += "\",\"side\":\"";
                    line += side;
                    line += "\",\"hull\":[";
                    line += std::to_string(hull_index);
                    line += ',';
                    line += std::to_string(hull_generation);
                    line += "],\"vertices\":[";
                    const auto append_vec3 = [&](core::Vec3 v) {
                        char buffer[128];
                        std::snprintf(buffer, sizeof(buffer), "[%.9g,%.9g,%.9g]", v.x, v.y, v.z);
                        line += buffer;
                    };
                    for (std::size_t i = 0; i < hull.vertices.size(); ++i) {
                        if (i != 0) line += ',';
                        append_vec3(hull.vertices[i]);
                    }
                    line += "],\"face_offsets\":[";
                    for (std::size_t i = 0; i < hull.face_offsets.size(); ++i) {
                        if (i != 0) line += ',';
                        line += std::to_string(hull.face_offsets[i]);
                    }
                    line += "],\"face_indices\":[";
                    for (std::size_t i = 0; i < hull.face_indices.size(); ++i) {
                        if (i != 0) line += ',';
                        line += std::to_string(hull.face_indices[i]);
                    }
                    line += "],\"face_normals\":[";
                    for (std::size_t i = 0; i < hull.face_normals.size(); ++i) {
                        if (i != 0) line += ',';
                        append_vec3(hull.face_normals[i]);
                    }
                    line += "]}";
                    std::fprintf(stderr, "%s\n", line.c_str());
                };
                dump_hull("A", *ha, sa.hull.index, sa.hull.generation);
                dump_hull("B", *hb, sb.hull.index, sb.hull.generation);
            }
        }
        if (!touching) {
            // The exact shapes do not overlap. For a CCD pair (either body opted in) inside a
            // real step, ask whether a fast approach will close the gap THIS tick and, if so,
            // emit a speculative contact so the solver can arrest the body at the surface
            // (M7.10). Passed in slot order, so the speculative normal is a → b like the exact
            // one. dt == 0 (the inspection seam) never speculates, keeping compute_contacts at
            // its M7.3 semantics.
            if (dt <= 0.0f || (ccd[da] == 0 && ccd[db] == 0)) {
                continue;
            }
            if (contact_profile_enabled) {
                ++contact_profile_last.speculative_calls;
            }
            bool speculative;
            {
                ContactTimer speculative_time(contact_profile_enabled,
                                              contact_profile_last.plain_speculative_ns);
                speculative = collide_speculative(shape[da],
                                                  position[da],
                                                  orientation[da],
                                                  linear_velocity[da],
                                                  shape[db],
                                                  position[db],
                                                  orientation[db],
                                                  linear_velocity[db],
                                                  dt,
                                                  m,
                                                  ha,
                                                  hb);
            }
            if (!speculative) {
                continue; // a broadphase near-miss, or too far / not approaching to matter
            }
        }

        // Warm-start from last tick's cache: match points by feature id and carry their
        // accumulated impulses into the fresh manifold. The stored generations guard against a
        // recycled slot inheriting a dead pair's impulses. A plain pair is region (0, 0).
        const std::uint64_t pair_key =
            (static_cast<std::uint64_t>(pr.a.index) << 32) | static_cast<std::uint64_t>(pr.b.index);
        {
            ContactTimer cache_time(contact_profile_enabled, contact_profile_last.warmcache_ns);
            const auto it = contact_cache.find(ContactCacheKey{pair_key, 0});
            if (it != contact_cache.end() && it->second.gen_a == pr.a.generation &&
                it->second.gen_b == pr.b.generation) {
                warm += warm_start_from(it->second, m);
            }
        }
        out.push_back(m);
    }
    warm_started_last = warm;
    if (contact_profile_enabled) {
        contact_profile_last.produced_manifolds = out.size();
    }
}

void PhysicsWorld::Impl::build_compound_contacts(const Pair& pr,
                                                 std::uint32_t da,
                                                 std::uint32_t db,
                                                 const CompoundShape* comp_a,
                                                 const CompoundShape* comp_b,
                                                 float dt,
                                                 std::vector<Manifold>& out,
                                                 std::uint32_t& warm) const {
    // Model A of ADR-0028, the narrowphase expansion: the broadphase reported ONE candidate pair
    // (compounds own a single union-bound proxy); here it fans out into child-vs-child sub-pairs.
    // A non-compound side counts as one child — its own shape at the body pose — so all four
    // combinations (compound-vs-primitive/hull/compound, either side) run through one loop. Every
    // stage is in FIXED order — a's child index ascending, then b's — so the emitted manifolds
    // extend the canonical pair order lexicographically by (child_a, child_b): determinism by
    // construction, no sorting needed (ADR-0026).

    // Pose each side's children once — O(children_a + children_b), not O(children_a·children_b) —
    // caching pose, resolved hull, and the tight world bound the cull below reads.
    struct PosedChild {
        const ShapeDesc* shape;
        const ConvexHull* hull;
        core::Vec3 pos;
        core::Quat orient;
        Aabb bounds;
    };

    // CCD (M7.10 × M7.12): a compound has no single support function (it is not convex), so
    // speculative contacts run PER CHILD — each child is convex and rides the body rigidly, so
    // its linear velocity is the body's (angular sweep ignored, exactly M7.10's documented
    // posture). For the cull to see a not-yet-touching-but-closing child pair at all, each side's
    // child bounds are swept by its body's velocity — the per-child mirror of the stage-1.5
    // proxy sweep.
    const bool ccd_pair = dt > 0.0f && (ccd[da] != 0 || ccd[db] != 0);
    const auto pose_side =
        [&](std::uint32_t dense, const CompoundShape* comp, std::vector<PosedChild>& list) {
            const core::Vec3 body_pos = position[dense];
            const core::Quat& body_q = orientation[dense];
            const std::size_t n = comp != nullptr ? comp->child_count() : 1;
            list.reserve(n);
            for (std::size_t i = 0; i < n; ++i) {
                PosedChild c{};
                if (comp != nullptr) {
                    c.shape = &comp->child_shape[i];
                    c.pos = compound_child_world_pos(*comp, i, body_pos, body_q);
                    c.orient = compound_child_world_orient(*comp, i, body_q);
                } else {
                    c.shape = &shape[dense];
                    c.pos = body_pos;
                    c.orient = body_q;
                }
                c.hull = hull_of(*c.shape);
                c.bounds = c.hull != nullptr ? hull_world_aabb(*c.hull, c.pos, c.orient)
                                             : compute_aabb(*c.shape, c.pos, c.orient);
                if (ccd_pair) {
                    const core::Vec3 sweep = linear_velocity[dense] * dt;
                    Aabb swept = c.bounds;
                    swept.min += sweep;
                    swept.max += sweep;
                    c.bounds = merge(c.bounds, swept);
                }
                list.push_back(c);
            }
        };
    std::vector<PosedChild> side_a;
    std::vector<PosedChild> side_b;
    {
        ContactTimer pose_time(contact_profile_enabled, contact_profile_last.compound_pose_ns);
        pose_side(da, comp_a, side_a);
        pose_side(db, comp_b, side_b);
    }
    if (contact_profile_enabled) {
        contact_profile_last.posed_children += side_a.size() + side_b.size();
    }

    const std::uint64_t pair_key =
        (static_cast<std::uint64_t>(pr.a.index) << 32) | static_cast<std::uint64_t>(pr.b.index);

    // One clock around the Cartesian loop avoids two clock reads for every cheap AABB rejection.
    // Subtract the disjoint exact/speculative/cache scopes afterwards: the remainder prices the
    // child-pair midphase, including its loop and manifold bookkeeping, without timing each cull.
    std::uint64_t child_loop_ns = 0;
    const std::uint64_t exact_before = contact_profile_last.compound_exact_ns;
    const std::uint64_t speculative_before = contact_profile_last.compound_speculative_ns;
    const std::uint64_t cache_before = contact_profile_last.warmcache_ns;
    {
        ContactTimer child_loop_time(contact_profile_enabled, child_loop_ns);
        for (std::size_t ia = 0; ia < side_a.size(); ++ia) {
            for (std::size_t ib = 0; ib < side_b.size(); ++ib) {
                const PosedChild& ca = side_a[ia];
                const PosedChild& cb = side_b[ib];
                // The v1 midphase: a brute-force child AABB cull, right at fracture-cell counts (a
                // child BVH is the measured-need follow-up, ADR-0028).
                const bool bounds_overlap =
                    overlaps(expanded(ca.bounds, kChildCullMargin), cb.bounds);
                if (contact_profile_enabled) {
                    ++contact_profile_last.tested_child_pairs;
                    if (!bounds_overlap) {
                        ++contact_profile_last.culled_child_pairs;
                    }
                }
                if (!bounds_overlap) {
                    continue;
                }

                Manifold m;
                m.a = pr.a;
                m.b = pr.b;
                m.child_a = static_cast<std::uint16_t>(ia);
                m.child_b = static_cast<std::uint16_t>(ib);
                // The children are convex, so each sub-pair runs the EXISTING per-convex-shape
                // routines unchanged — passed in body slot order, so the normal is a → b exactly as
                // the plain path's (contact.hpp). The solver later applies the manifold to the
                // PARENT bodies: contact points are world-space and lever arms come from the parent
                // COM, which is precisely what "rigidly attached child" means.
                bool touching;
                {
                    ContactTimer narrow_time(contact_profile_enabled,
                                             contact_profile_last.compound_exact_ns);
                    if (contact_profile_enabled) {
                        ++contact_profile_last.exact_narrowphase_calls;
                    }
                    touching = collide_shapes(*ca.shape,
                                              ca.pos,
                                              ca.orient,
                                              *cb.shape,
                                              cb.pos,
                                              cb.orient,
                                              m,
                                              ca.hull,
                                              cb.hull) &&
                               m.count != 0;
                }
                if (!touching) {
                    if (!ccd_pair) {
                        continue;
                    }
                    if (contact_profile_enabled) {
                        ++contact_profile_last.speculative_calls;
                    }
                    bool speculative;
                    {
                        ContactTimer speculative_time(contact_profile_enabled,
                                                      contact_profile_last.compound_speculative_ns);
                        speculative = collide_speculative(*ca.shape,
                                                          ca.pos,
                                                          ca.orient,
                                                          linear_velocity[da],
                                                          *cb.shape,
                                                          cb.pos,
                                                          cb.orient,
                                                          linear_velocity[db],
                                                          dt,
                                                          m,
                                                          ca.hull,
                                                          cb.hull);
                    }
                    if (!speculative) {
                        continue; // this child pair is separated and not imminently closing
                    }
                }

                // Fold the child indices into every feature id (kFeatCompoundChild): two children
                // touching the same other shape through identical child-local features must still
                // carry DISTINCT ids. Applied uniformly to every pair that involves a compound —
                // and never to plain pairs, whose id spaces stay bit-identical to M7.11 (the
                // backward-compat contract).
                const std::uint32_t child_fold = feature_combine(
                    feature_combine(kFeatCompoundChild, static_cast<std::uint32_t>(ia)),
                    static_cast<std::uint32_t>(ib));
                for (std::uint8_t k = 0; k < m.count; ++k) {
                    m.points[k].feature_id = feature_combine(child_fold, m.points[k].feature_id);
                }

                // Warm-start from this REGION's own cache entry — (pair, child_a, child_b) — so one
                // foot of a standing compound can never inherit the other foot's impulses.
                const ContactCacheKey key{pair_key,
                                          (static_cast<std::uint32_t>(ia) << 16) |
                                              static_cast<std::uint32_t>(ib)};
                {
                    ContactTimer cache_time(contact_profile_enabled,
                                            contact_profile_last.warmcache_ns);
                    const auto it = contact_cache.find(key);
                    if (it != contact_cache.end() && it->second.gen_a == pr.a.generation &&
                        it->second.gen_b == pr.b.generation) {
                        warm += warm_start_from(it->second, m);
                    }
                }
                out.push_back(m);
            }
        }
    }
    if (contact_profile_enabled) {
        const std::uint64_t timed_regions =
            (contact_profile_last.compound_exact_ns - exact_before) +
            (contact_profile_last.compound_speculative_ns - speculative_before) +
            (contact_profile_last.warmcache_ns - cache_before);
        contact_profile_last.compound_midphase_ns += child_loop_ns - timed_regions;
    }
}

void PhysicsWorld::Impl::build_heightfield_contacts(const Pair& pr,
                                                    std::uint32_t da,
                                                    std::uint32_t db,
                                                    float dt,
                                                    std::vector<Manifold>& out,
                                                    std::uint32_t& warm) const {
    // Which side is the terrain? Canonical pair order is by SLOT, not by shape, so it may be
    // either — and the manifold normal must point a → b whichever it is.
    const bool terrain_is_a = shape[da].type == ShapeType::Heightfield;
    const std::uint32_t dt_ = terrain_is_a ? da : db; // the terrain's dense index
    const std::uint32_t dbody = terrain_is_a ? db : da;
    const HeightfieldShape* hf = heightfield_of(shape[dt_]);
    if (hf == nullptr) {
        return; // unreachable: create_body refuses an unresolved heightfield id
    }

    // Work in the terrain's LOCAL frame: pose the body there once (the inverse of the tile's
    // pose), generate, and pose results back. A yawed tile then costs one extra rotation per
    // body, and every per-triangle routine can assume "up is +Y, the grid is axis-aligned".
    const core::Quat tq = orientation[dt_];
    const core::Vec3 tp = position[dt_];
    const core::Quat tqc = core::conjugate(tq);
    const core::Vec3 body_pos = position[dbody];
    const core::Quat& body_q = orientation[dbody];

    // A compound body is opened one level, exactly as build_compound_contacts does: each convex
    // child collides with the terrain on its own, and its index rides the child slot of the
    // manifold on the body's side.
    const CompoundShape* comp = compound_of(shape[dbody]);
    const std::size_t n_children = comp != nullptr ? comp->child_count() : 1;
    const std::uint64_t pair_key =
        (static_cast<std::uint64_t>(pr.a.index) << 32) | static_cast<std::uint64_t>(pr.b.index);

    // KNOWN LIMITATION, named rather than fixed (M19.1): these two vectors — and each patch's
    // own `members` — are heap-allocated per terrain pair per step. The narrowphase loop that
    // calls this is SERIAL (`for (const Pair& pr : pairs)` in step()), so they could be hoisted to
    // persistent `mutable` scratch on Impl with no data race; that is deliberately not done here
    // because nothing has measured it. No shipped scene has terrain in it yet, so the cost today
    // is zero, and ADR-0035 §2c's rule is that an optimisation arrives with its measurement. When
    // M19's streaming brick puts terrain under a body count that matters, measure here first:
    // the roadmap already names the every-tick narrowphase cache as the next physics hot spot.
    std::vector<HeightfieldContact> cands;
    std::vector<HeightfieldPatch> patches;
    bool any = false;
    for (std::size_t ci = 0; ci < n_children; ++ci) {
        const ShapeDesc* cs = &shape[dbody];
        core::Vec3 cpos = body_pos;
        core::Quat cq = body_q;
        if (comp != nullptr) {
            cs = &comp->child_shape[ci];
            cpos = compound_child_world_pos(*comp, ci, body_pos, body_q);
            cq = compound_child_world_orient(*comp, ci, body_q);
        }
        const std::uint32_t seed =
            feature_combine(heightfield_detail::kFeatHeightfield, static_cast<std::uint32_t>(ci));
        cands.clear();
        heightfield_contacts_local(
            *hf, *cs, core::rotate(tqc, cpos - tp), tqc * cq, hull_of(*cs), seed, cands);
        if (cands.empty()) {
            continue;
        }
        any = true;
        hf_patch_merges_last += group_patches(cands, patches);

        const auto child16 = static_cast<std::uint16_t>(ci);
        for (const HeightfieldPatch& patch : patches) {
            Manifold m;
            m.a = pr.a;
            m.b = pr.b;
            m.child_a = terrain_is_a ? std::uint16_t{0} : child16;
            m.child_b = terrain_is_a ? child16 : std::uint16_t{0};
            patch_to_manifold(patch, cands, tp, tq, m);
            if (m.count == 0) {
                continue;
            }
            if (!terrain_is_a) {
                m.normal = -m.normal; // patch normals point terrain → body; a is the body here
            }
            const ContactCacheKey key{pair_key,
                                      (static_cast<std::uint32_t>(m.child_a) << 16) |
                                          static_cast<std::uint32_t>(m.child_b),
                                      m.patch};
            const auto it = contact_cache.find(key);
            if (it != contact_cache.end() && it->second.gen_a == pr.a.generation &&
                it->second.gen_b == pr.b.generation) {
                warm += warm_start_from(it->second, m);
            }
            out.push_back(m);
        }
    }
    // No exact contact, and the body asked for CCD: speculate against terrain (m19.2). M7.10's
    // rule is GJK-based and therefore shape-agnostic once it is expressed over support functions,
    // which is what `collide_speculative_supports` now is — so a body approaching terrain fast is
    // arrested by exactly the same closing-speed condition that arrests it against a wall, rather
    // than by a second rule invented for terrain. A compound is opened one level here too, because
    // each child is convex and rides the body rigidly.
    // Nothing imminent is simply no contact; only a TRUNCATED look bumps hf_ccd_skipped, so the
    // counter keeps meaning "could not look" rather than "found nothing".
    if (!any && dt > 0.0f && ccd[dbody] != 0) {
        for (std::size_t ci = 0; ci < n_children; ++ci) {
            const ShapeDesc* cs = &shape[dbody];
            core::Vec3 cpos = body_pos;
            core::Quat cq = body_q;
            if (comp != nullptr) {
                cs = &comp->child_shape[ci];
                cpos = compound_child_world_pos(*comp, ci, body_pos, body_q);
                cq = compound_child_world_orient(*comp, ci, body_q);
            }
            Manifold m;
            bool truncated = false;
            if (contact_profile_enabled) {
                ++contact_profile_last.speculative_calls;
            }
            if (!speculative_vs_heightfield_local(*hf,
                                                  *cs,
                                                  core::rotate(tqc, cpos - tp),
                                                  tqc * cq,
                                                  hull_of(*cs),
                                                  core::rotate(tqc, linear_velocity[dbody]),
                                                  dt,
                                                  m,
                                                  truncated)) {
                if (truncated) {
                    ++hf_ccd_skipped_last;
                }
                continue;
            }
            // Back into world space, then into SLOT order — the identical two steps the exact
            // path above takes, because the local routine was made to use the same terrain → body
            // convention `patch_to_manifold` does. The manifold normal is a → b for every other
            // pair and must be here too, or the solver pushes the body the wrong way.
            m.normal = core::rotate(orientation[dt_], m.normal);
            m.points[0].position = tp + core::rotate(orientation[dt_], m.points[0].position);
            if (!terrain_is_a) {
                m.normal = m.normal * -1.0f;
            }
            m.a = pr.a;
            m.b = pr.b;
            const auto child16 = static_cast<std::uint16_t>(ci);
            m.child_a = terrain_is_a ? std::uint16_t{0} : child16;
            m.child_b = terrain_is_a ? child16 : std::uint16_t{0};
            m.patch = 0; // a speculative contact is one point, not a surface region
            out.push_back(m);
        }
    }
}

void PhysicsWorld::Impl::commit_contact_cache(const std::vector<Manifold>& manifolds) const {
    // Rebuild the persistent cache from this tick's manifolds — in step() they are the SOLVED
    // manifolds, so the impulses that carry to next tick are the converged ones (the whole point
    // of warm starting). Keyed per contact REGION: the broadphase pair key ((slot_a << 32) |
    // slot_b) plus the packed child sub-pair (0 for plain pairs — M7.12), which is exactly why a
    // pair carrying several compound manifolds commits several entries instead of silently
    // keeping only the first. A flat hash map is plenty here — lookups are per-region, nothing
    // ever iterates it, so its unordered-ness cannot leak into simulation order (the determinism
    // contract).
    std::unordered_map<ContactCacheKey, ManifoldCacheEntry, ContactCacheKeyHash> next;
    next.reserve(manifolds.size());
    for (const Manifold& m : manifolds) {
        const std::uint64_t pair_key =
            (static_cast<std::uint64_t>(m.a.index) << 32) | static_cast<std::uint64_t>(m.b.index);
        const ContactCacheKey key{pair_key,
                                  (static_cast<std::uint32_t>(m.child_a) << 16) |
                                      static_cast<std::uint32_t>(m.child_b),
                                  m.patch};
        next.emplace(key, make_cache_entry(pair_key, m.a.generation, m.b.generation, m));
    }
    contact_cache.swap(next);
}

PhysicsWorld::PhysicsWorld() : impl_(std::make_unique<Impl>()) {
    impl_->set_zone_label({}); // the unlabelled `physics.<stage>` names, unchanged since m17.3b
}

PhysicsWorld::~PhysicsWorld() = default;

BodyId PhysicsWorld::create_body(const BodyDesc& d) {
    Impl& p = *impl_;

    // A hull- or compound-shaped body must reference a store entry THIS world knows, or the body
    // would have no geometry to collide, bound, or weigh. Refusing with the null id (rather than
    // creating a ghost) keeps the failure at the call site that made it.
    if (d.shape.type == ShapeType::ConvexHull && p.hull_of(d.shape) == nullptr) {
        return BodyId{};
    }
    if (d.shape.type == ShapeType::Compound && p.compound_of(d.shape) == nullptr) {
        return BodyId{};
    }
    // Terrain must resolve AND be static (M19.1): a heightfield has no meaningful mass
    // distribution and the contact path assumes it never moves under a resting body.
    if (d.shape.type == ShapeType::Heightfield &&
        (p.heightfield_of(d.shape) == nullptr || d.motion != MotionType::Static)) {
        return BodyId{};
    }

    // The shape id is now known-valid (checked just above), and the rest of create_body cannot
    // fail — so take the store reference here (M8.5): this body now holds hull/compound i, and
    // unregister refuses to free geometry a live body still names. destroy_body drops it again.
    if (d.shape.type == ShapeType::ConvexHull) {
        ++p.hull_refs[d.shape.hull.index];
    } else if (d.shape.type == ShapeType::Compound) {
        ++p.compound_refs[d.shape.compound.index];
    } else if (d.shape.type == ShapeType::Heightfield) {
        ++p.heightfield_refs[d.shape.heightfield.index];
    }

    // Claim a slot (reuse a freed one to keep the table compact; its generation was already
    // bumped).
    std::uint32_t slot;
    if (!p.free_slots.empty()) {
        slot = p.free_slots.back();
        p.free_slots.pop_back();
    } else {
        slot = static_cast<std::uint32_t>(p.slots.size());
        p.slots.push_back(Impl::Slot{});
    }

    const bool dynamic = d.motion == MotionType::Dynamic;
    const float mass = d.mass > 0.0f ? d.mass : 1.0f;
    // Mass distribution: primitives have closed forms (shape.hpp); a hull's principal moments
    // were integrated at registration (per unit mass — inertia scales linearly with mass at
    // fixed geometry) and its principal-axis rotation rides along in the SoA column, identity
    // for every other shape. A compound's moments were COMPOSED at registration the same way
    // (parallel-axis over the children, ADR-0028) — the body just scales them by its mass, and
    // its `position` is the compound's COM because the store re-centred the child poses.
    MassProperties mp = compute_mass_properties(d.shape, mass);
    core::Quat principal = core::quat_identity();
    if (const ConvexHull* h = p.hull_of(d.shape); h != nullptr) {
        mp.inertia_diagonal = h->inertia_per_mass * mass;
        principal = h->principal;
    } else if (const CompoundShape* c = p.compound_of(d.shape); c != nullptr) {
        mp.inertia_diagonal = c->inertia_per_mass * mass;
        principal = c->principal;
    }
    const float im = dynamic ? inv_or_zero(mp.mass) : 0.0f;
    const core::Vec3 ii = dynamic ? core::Vec3{inv_or_zero(mp.inertia_diagonal.x),
                                               inv_or_zero(mp.inertia_diagonal.y),
                                               inv_or_zero(mp.inertia_diagonal.z)}
                                  : core::Vec3{0.0f, 0.0f, 0.0f};
    const core::Quat orient = core::normalize(d.orientation);

    // Insert the broadphase proxy tagged with the stable slot id, so a query returns slot ids
    // directly (mappable back to a BodyId without touching the dense arrays).
    const Aabb tight = p.aabb_of(d.shape, d.position, orient);
    const auto motion8 = static_cast<std::uint8_t>(d.motion);
    const std::int32_t proxy = p.tree_for(motion8).create_proxy(tight, slot);

    const auto dense = static_cast<std::uint32_t>(p.count());
    p.position.push_back(d.position);
    p.orientation.push_back(orient);
    p.linear_velocity.push_back(d.linear_velocity);
    p.angular_velocity.push_back(d.angular_velocity);
    p.inv_mass.push_back(im);
    p.inv_inertia.push_back(ii);
    p.inertia_principal.push_back(principal);
    p.inertia_orientation.push_back(orient * principal);
    p.motion.push_back(motion8);
    p.linear_damping.push_back(d.linear_damping);
    p.angular_damping.push_back(d.angular_damping);
    p.gravity_factor.push_back(d.gravity_factor);
    p.friction.push_back(d.friction);
    p.restitution.push_back(d.restitution);
    p.ccd.push_back(d.ccd ? std::uint8_t{1} : std::uint8_t{0});
    p.sensor.push_back(d.sensor ? std::uint8_t{1} : std::uint8_t{0});
    p.sleep_timer.push_back(0.0f);
    p.rest_anchor_position.push_back(d.position);
    p.rest_anchor_orientation.push_back(orient); // the NORMALISED one that was stored
    p.pose_rest_timer.push_back(0.0f);
    p.asleep.push_back(0); // a freshly created body always starts awake
    p.shape.push_back(d.shape);
    p.proxy.push_back(proxy);
    p.dense_to_slot.push_back(slot);

    p.slots[slot].dense = dense;
    return BodyId{slot, p.slots[slot].generation};
}

void PhysicsWorld::destroy_body(BodyId id) {
    Impl& p = *impl_;
    const std::uint32_t d = p.dense_of(id);
    if (d == core::kInvalidSlotIndex) {
        return; // stale/unknown — safe no-op
    }

    // Capture the shape reference BEFORE the swap-remove below overwrites p.shape[d]; the store
    // reference this body held is released at the end (M8.5), the mirror of create_body's
    // increment.
    const ShapeDesc released_shape = p.shape[d];

    // Removing a collider can remove a sleeper's support without creating an awake contact.
    // Island propagation alone cannot notice that: the remaining island is still wholly asleep
    // and skips gravity forever. Wake only sleeping dynamics in the old fat-AABB neighborhood
    // before removing the proxy. The broadphase margin includes resting/speculative contacts;
    // conservative extra neighbors are harmless, and the next step propagates through their
    // remaining contact islands. Each wake is independent, so tree traversal order is irrelevant.
    // Sensors never supported anything. Querying in place needs no temporary neighbor roster.
    if (p.sensor[d] == 0) {
        const Aabb removed_bounds = p.tree_for(p.motion[d]).proxy_aabb(p.proxy[d]);
        p.dynamic_tree.query(removed_bounds, [&](std::uint32_t slot) {
            if (slot == id.index) {
                return;
            }
            const std::uint32_t neighbor = p.slots[slot].dense;
            if (p.motion[neighbor] == static_cast<std::uint8_t>(MotionType::Dynamic) &&
                p.sensor[neighbor] == 0 && p.asleep[neighbor] != 0) {
                p.asleep[neighbor] = 0;
                p.clear_rest(neighbor);
            }
        });
    }

    // Drop this body's broadphase proxy first (its tree is chosen by the current motion type).
    p.tree_for(p.motion[d]).destroy_proxy(p.proxy[d]);

    const auto last = static_cast<std::uint32_t>(p.count() - 1);
    if (d != last) {
        // Swap-remove: move the last body into the hole so the arrays stay dense. The moved body's
        // proxy node is untouched (it is keyed by the stable slot id), just relocated in the array.
        p.position[d] = p.position[last];
        p.orientation[d] = p.orientation[last];
        p.linear_velocity[d] = p.linear_velocity[last];
        p.angular_velocity[d] = p.angular_velocity[last];
        p.inv_mass[d] = p.inv_mass[last];
        p.inv_inertia[d] = p.inv_inertia[last];
        p.inertia_principal[d] = p.inertia_principal[last];
        p.inertia_orientation[d] = p.inertia_orientation[last];
        p.motion[d] = p.motion[last];
        p.linear_damping[d] = p.linear_damping[last];
        p.angular_damping[d] = p.angular_damping[last];
        p.gravity_factor[d] = p.gravity_factor[last];
        p.friction[d] = p.friction[last];
        p.restitution[d] = p.restitution[last];
        p.ccd[d] = p.ccd[last];
        p.sensor[d] = p.sensor[last];
        p.sleep_timer[d] = p.sleep_timer[last];
        p.rest_anchor_position[d] = p.rest_anchor_position[last];
        p.rest_anchor_orientation[d] = p.rest_anchor_orientation[last];
        p.pose_rest_timer[d] = p.pose_rest_timer[last];
        p.asleep[d] = p.asleep[last];
        p.shape[d] = p.shape[last];
        p.proxy[d] = p.proxy[last];
        const std::uint32_t moved_slot = p.dense_to_slot[last];
        p.dense_to_slot[d] = moved_slot;
        p.slots[moved_slot].dense = d; // the moved body now lives at d
    }
    p.position.pop_back();
    p.orientation.pop_back();
    p.linear_velocity.pop_back();
    p.angular_velocity.pop_back();
    p.inv_mass.pop_back();
    p.inv_inertia.pop_back();
    p.inertia_principal.pop_back();
    p.inertia_orientation.pop_back();
    p.motion.pop_back();
    p.linear_damping.pop_back();
    p.angular_damping.pop_back();
    p.gravity_factor.pop_back();
    p.friction.pop_back();
    p.restitution.pop_back();
    p.ccd.pop_back();
    p.sensor.pop_back();
    p.sleep_timer.pop_back();
    p.rest_anchor_position.pop_back();
    p.rest_anchor_orientation.pop_back();
    p.pose_rest_timer.pop_back();
    p.asleep.pop_back();
    p.shape.pop_back();
    p.proxy.pop_back();
    p.dense_to_slot.pop_back();

    // Free the slot and bump its generation so old ids referencing it read as dead.
    p.slots[id.index].dense = core::kInvalidSlotIndex;
    ++p.slots[id.index].generation;
    p.free_slots.push_back(id.index);

    // Release the hull/compound reference this body held (M8.5). Guarded against underflow — a
    // primitive-shaped body holds none, and the count was incremented at create for exactly the
    // hull/compound shapes.
    if (released_shape.type == ShapeType::ConvexHull &&
        released_shape.hull.index < p.hull_refs.size() &&
        p.hull_refs[released_shape.hull.index] > 0) {
        --p.hull_refs[released_shape.hull.index];
    } else if (released_shape.type == ShapeType::Compound &&
               released_shape.compound.index < p.compound_refs.size() &&
               p.compound_refs[released_shape.compound.index] > 0) {
        --p.compound_refs[released_shape.compound.index];
    } else if (released_shape.type == ShapeType::Heightfield &&
               released_shape.heightfield.index < p.heightfield_refs.size() &&
               p.heightfield_refs[released_shape.heightfield.index] > 0) {
        --p.heightfield_refs[released_shape.heightfield.index];
    }
}

bool PhysicsWorld::get_body_state(BodyId id, BodyState& out) const {
    const std::uint32_t d = impl_->dense_of(id);
    if (d == core::kInvalidSlotIndex) {
        return false;
    }
    out.position = impl_->position[d];
    out.orientation = impl_->orientation[d];
    out.linear_velocity = impl_->linear_velocity[d];
    out.angular_velocity = impl_->angular_velocity[d];
    return true;
}

bool PhysicsWorld::set_body_state(BodyId id, const BodyState& state) {
    Impl& p = *impl_;
    const std::uint32_t d = p.dense_of(id);
    if (d == core::kInvalidSlotIndex) {
        return false;
    }
    p.position[d] = state.position;
    p.orientation[d] = core::normalize(state.orientation);
    p.linear_velocity[d] = state.linear_velocity;
    p.angular_velocity[d] = state.angular_velocity;

    // Wake it: an asleep body is asserting it has come to rest where it stands, which a teleport
    // has just made false. Clearing the timer too, so it has to earn sleep again from scratch.
    p.asleep[d] = 0;
    p.clear_rest(d);

    // Refit the proxy to where the body actually is now. step()'s stage-8 refit only covers active
    // islands, so without this a body moved while asleep keeps a proxy at its old pose (see the
    // header for why that failure surfaces far from its cause).
    p.tree_for(p.motion[d])
        .move_proxy(p.proxy[d], p.aabb_of(p.shape[d], p.position[d], p.orientation[d]));
    return true;
}

bool PhysicsWorld::is_alive(BodyId id) const noexcept {
    return impl_->dense_of(id) != core::kInvalidSlotIndex;
}

std::size_t PhysicsWorld::body_count() const noexcept {
    return impl_->count();
}

void PhysicsWorld::set_gravity(core::Vec3 g) noexcept {
    impl_->gravity = g;
}

core::Vec3 PhysicsWorld::gravity() const noexcept {
    return impl_->gravity;
}

void PhysicsWorld::step(float dt) {
    // THE STEP'S STAGES ARE MEASURED (m17.3b, ADR-0041 Ruling 2). Before this, the entire engine
    // held ten profile zones and every one of them was in `application.cpp` — nothing in physics,
    // destruction, render or net. So `99-the-block`'s largest cost, `sim.block` at a p99 of
    // 25.49 ms against a ratified 6.0, had no attribution of any kind, and ADR-0035 §6's prediction
    // that the narrowphase is the hot spot has been quoted as measured for two milestones without
    // ever being measured.
    //
    // The zones sit at STAGE granularity, which is the same rule `Application` follows and for the
    // same reason: `report_zone` takes a lock to fetch the sink, so a zone inside a per-body loop
    // would cost more than it measures.
    //
    // They also stay on the CALLING thread — none goes inside `solve_island`, which the job system
    // runs on workers — and the reason is stronger than cost, so say it exactly. `report_zone`
    // copies the sink out under its mutex and then **invokes it unlocked** (profile.cpp), on
    // purpose: a sink may do real work and holding a global lock across it would serialize whatever
    // called it. So the lock protects the sink SLOT, not the sink's own state, and the sink
    // installed here — `ZoneTimelines`, feeding `PerfReport::observe_zone` — mutates plain vectors
    // with no synchronization at all. A zone on a worker would therefore not be "contended and
    // slow"; it would be a DATA RACE on the report, and the first vector reallocation under it is
    // a crash or silent corruption of the numbers the milestone is about to trust. Do not accept
    // it "just for a debug session": undefined behaviour does not become safe by being temporary.
    // `ZoneTimelines` refuses foreign-thread zones and counts them, so the hazard is enforced
    // rather than merely written down here.
    //
    // With no sink installed each zone is two clock reads, one uncontended lock and an early
    // return, which is every shipping run and every CI run.
    RIME_PROFILE_ZONE(impl_->zone(StepZone::Step));
    Impl& p = *impl_;
    const std::size_t n = p.count();
    const auto is_dynamic = [&](std::size_t i) {
        return p.motion[i] == static_cast<std::uint8_t>(MotionType::Dynamic);
    };

    // Snapshot the sleep state up front (M7.9): the tail diffs it against the post-step `asleep` to
    // emit sleep/wake events for exactly the transitions THIS step caused. Dense indices are stable
    // through a step (create/destroy happen only between steps), so snapshot[i] and asleep[i] name
    // the same body at both ends.
    p.asleep_snapshot.assign(p.asleep.begin(), p.asleep.end());

    // The M7.5 tick keeps the M7.4 sequential-impulse pipeline but wraps it in ISLANDS and
    // SLEEPING. Its shape:
    //   integrate velocities (awake) → detect contacts → prepare constraints → PARTITION into
    //   islands → wake/skip islands → solve each island (job system) → update sleeping → commit the
    //   cache + refit moved proxies.
    // Two properties carry over from M7.4: WHERE position integration sits (symplectic — velocity
    // first, solver corrects it, then position follows, so a resting body's gravity is cancelled in
    // the same tick), and DETERMINISM (dense/canonical order, fixed iteration counts). M7.5 adds a
    // stronger determinism claim: the per-island solve is the ONLY parallel region, islands share
    // no dynamic body, and immovable bodies are read-only in the solver — so the tick is
    // bit-identical for any worker-thread count (ADR-0026; world_hash() is the witness).

    // ---- 1. Integrate velocities (not positions yet) for AWAKE dynamic bodies. Gravity is an
    // acceleration (mass-independent) so it enters velocity directly; damping is the implicit
    // 1/(1+c·dt) form, unconditionally stable. Asleep bodies are frozen — skipping them here is the
    // whole point of sleeping: a resting stack costs nothing. (Kinematic push-in is M7.6; the
    // gyroscopic ω×Iω term stays dropped, ADR-0026.)
    {
        RIME_PROFILE_ZONE(p.zone(StepZone::IntegrateVelocity));
        for (std::size_t i = 0; i < n; ++i) {
            if (!is_dynamic(i) || p.asleep[i] != 0) {
                continue;
            }
            core::Vec3 v = p.linear_velocity[i] + p.gravity * (p.gravity_factor[i] * dt);
            v *= 1.0f / (1.0f + p.linear_damping[i] * dt);
            p.linear_velocity[i] = v;
            p.angular_velocity[i] *= 1.0f / (1.0f + p.angular_damping[i] * dt);
        }
    }

    // ---- 1.5 Sweep CCD proxies (M7.10). A body opted into continuous collision gets its
    // broadphase bound expanded to enclose where it WILL be this tick (position + post-gravity
    // velocity·dt), so the broadphase reports a thin obstacle in its path BEFORE the shapes overlap
    // — the precondition for stage 2's speculative test to see the pair at all. Done here, ahead of
    // the broadphase and every tick (not folded into the stage-8 refit), so a body that is fast
    // from the moment it spawns is covered on its very first step. Sequential, before the parallel
    // region; move_proxy adds the fat margin on top, and the stage-8 refit later restores the tight
    // box at the body's real resting position for external queries.
    if (dt > 0.0f) {
        RIME_PROFILE_ZONE(p.zone(StepZone::CcdSweep));
        for (std::size_t i = 0; i < n; ++i) {
            if (p.ccd[i] == 0 || !is_dynamic(i) || p.asleep[i] != 0) {
                continue; // CCD only helps a moving, awake, dynamic body (see docs/design)
            }
            const Aabb tight = p.aabb_of(p.shape[i], p.position[i], p.orientation[i]);
            const core::Vec3 predicted = p.position[i] + p.linear_velocity[i] * dt;
            const Aabb swept = merge(tight, p.aabb_of(p.shape[i], predicted, p.orientation[i]));
            p.dynamic_tree.move_proxy(p.proxy[i], swept);
        }
    }

    // ---- 2. Detect contacts: broadphase pairs → narrowphase manifolds, warm-started from last
    // tick's cache (committed post-solve at stage 8, so warm starts carry SOLVED impulses). Runs
    // for ALL bodies, asleep included: a new contact between a faller and a sleeping stack is
    // exactly how the stack learns to wake — stage 4 merges them into one island, stage 5
    // reactivates it. With CCD (M7.10), dt > 0 also lets an approaching fast pair get a speculative
    // contact from the swept bounds set just above.
    // The stage ADR-0035 §6 predicted would dominate at 400+ debris. This zone is what turns that
    // prediction into a measurement — or refutes it.
    std::vector<Manifold> manifolds;
    {
        RIME_PROFILE_ZONE(p.zone(StepZone::Contacts));
        p.build_contacts(manifolds, dt);
    }

    // ---- 2.5 Materialize each body's world inverse inertia, BEFORE the solver's view of the
    // bodies is built and before anything reads it. One sequential pass over ALL dense bodies, on
    // this thread, outside every parallel region — statics are anchors shared between islands, so a
    // per-island fill would be a cross-island write race on them.
    //
    // Two things are filled in the one pass, because they are the same arithmetic read twice. The
    // composite orientation·principal is still the quantity the NGS pass's live 4-argument
    // apply_inv_inertia composes per use (same multiply, same operand order, so it stays
    // bit-identical to composing inline — tests/physics/solver_test.cpp asserts that bitwise), and
    // it is also the rotation the tensor below is built from.
    //
    // make_inverse_inertia_world (solver.hpp) is the whole of the second quantity, so the formula
    // lives in one place and tests/physics/solver_test.cpp can drive the same code this loop runs.
    // Materializing it is a deliberate numerical change, NOT a refactor: the velocity phase then
    // multiplies by six stored floats instead of rotating into the eigenframe and back, which is
    // the same answer along a different arithmetic path. ADR-0026's bit-identity guarantee is
    // across worker counts and is untouched; what moves is the last bits of a float, and the
    // collapse of a fracture cascade is sensitive to those (see CLAUDE.md on the 29 --headless
    // claims). The measurement that justifies it is the fixed-workload solver bench, not a sample.
    p.inverse_inertia_world.resize(p.orientation.size());
    for (std::size_t i = 0; i < p.orientation.size(); ++i) {
        const core::Quat q = p.orientation[i] * p.inertia_principal[i];
        p.inertia_orientation[i] = q;
        p.inverse_inertia_world[i] = make_inverse_inertia_world(q, p.inv_inertia[i]);
    }

    // ---- 3. Prepare the contact constraints (solver.hpp). prepare_contact_constraint reads the
    // post-gravity velocities to fix each restitution bias, so it must precede any warm-start
    // impulse (the M7.4 ordering, preserved). Pairs with no dynamic participant are skipped — an
    // impulse could never move either end.
    SolverBodies bodies{p.position.data(),
                        p.orientation.data(),
                        p.linear_velocity.data(),
                        p.angular_velocity.data(),
                        p.inv_mass.data(),
                        p.inv_inertia.data(),
                        p.inertia_principal.data(),
                        p.inertia_orientation.data(),
                        p.friction.data(),
                        p.restitution.data(),
                        p.inverse_inertia_world.data()};
    std::vector<ContactConstraint> constraints;
    constraints.reserve(manifolds.size());
    {
        RIME_PROFILE_ZONE(p.zone(StepZone::Constraints));
        for (std::size_t mi = 0; mi < manifolds.size(); ++mi) {
            const Manifold& m = manifolds[mi];
            const std::uint32_t da = p.dense_of(m.a);
            const std::uint32_t db = p.dense_of(m.b);
            if (da == core::kInvalidSlotIndex || db == core::kInvalidSlotIndex) {
                continue; // defensive: build_contacts only emits live pairs
            }
            if (p.inv_mass[da] + p.inv_mass[db] <= 0.0f) {
                continue; // no dynamic member — immovable pair, nothing solvable
            }
            // A SENSOR EXCHANGES NO IMPULSE (m15.6). Skipping it here, and only here, is what makes
            // a trigger a trigger: it still runs through the broadphase and the exact narrowphase —
            // the overlap is real geometry, not an AABB guess — but it never becomes a constraint,
            // so it never joins an island, never wakes a stack, and cannot push anything. The
            // manifold survives to the event stage below, where it is reported as a trigger
            // instead.
            if (p.sensor[da] != 0 || p.sensor[db] != 0) {
                continue;
            }
            constraints.push_back(
                prepare_contact_constraint(bodies, m, da, db, static_cast<std::uint32_t>(mi), dt));
        }
    } // physics.constraints

    // ---- 4. Partition into ISLANDS (islands.hpp): connected components of the dynamic-body
    // contact graph. Every awake dynamic body lands in exactly one island (a contactless body is a
    // singleton); static/kinematic bodies are shared anchors, not island members.
    //
    // Gather the constraints into island-contiguous order so each island solves a plain span (the
    // solver stays index-free). Within-island order is preserved, so an island's solve is
    // bit-identical to M7.4's flat solve restricted to that island's bodies — the flat solve's
    // other constraints never touched them, so interleaving them or not cannot change the result.
    std::vector<ContactConstraint> ordered;
    {
        RIME_PROFILE_ZONE(p.zone(StepZone::Islands));
        build_islands(n, p.motion, constraints, p.islands);
        ordered.resize(p.islands.constraints.size());
        for (std::size_t i = 0; i < p.islands.constraints.size(); ++i) {
            ordered[i] = constraints[p.islands.constraints[i]];
        }
    }
    const IslandSet& isl = p.islands;

    // ---- 5. Decide which islands are ACTIVE this tick. An island is active unless every one of
    // its bodies is still asleep; a single awake member (e.g. a body that just fell in and merged
    // at stage 4) reactivates the whole island, and reactivated bodies restart their sleep timer.
    // With sleeping disabled no body is ever asleep, so every island is active — same code path.
    std::vector<std::uint8_t> active(isl.island_count, 1);
    std::size_t active_count = 0;
    {
        RIME_PROFILE_ZONE(p.zone(StepZone::Wake));
        for (std::size_t k = 0; k < isl.island_count; ++k) {
            bool any_awake = false;
            for (std::uint32_t bi = isl.body_offsets[k]; bi < isl.body_offsets[k + 1]; ++bi) {
                if (p.asleep[isl.bodies[bi]] == 0) {
                    any_awake = true;
                    break;
                }
            }
            active[k] = any_awake ? std::uint8_t{1} : std::uint8_t{0};
            active_count += any_awake ? 1u : 0u;
            if (any_awake) {
                for (std::uint32_t bi = isl.body_offsets[k]; bi < isl.body_offsets[k + 1]; ++bi) {
                    const std::uint32_t b = isl.bodies[bi];
                    if (p.asleep[b] != 0) { // a neighbour is moving — rejoin the simulation
                        p.asleep[b] = 0;
                        p.clear_rest(b);
                    }
                }
            }
        }
    } // physics.wake

    // ---- 6. Solve the ACTIVE islands. Per island, the exact M7.4 sequence — warm-start, fixed
    // velocity iterations, store impulses, integrate positions with the post-solve velocities, then
    // the fixed NGS position iterations — runs strictly sequentially. Islands write disjoint
    // dynamic bodies (immovable anchors are read-only), so the job system runs them in parallel
    // with no locks and the result is identical to the sequential loop, bit for bit, at any thread
    // count.
    //
    // ONE body, two instantiations. `Profile` is a compile-time bool, so the profile-off
    // instantiation contains no clock call, no slot write and no branch, and the solve sequence is
    // written exactly once — two hand-kept copies of it is how a solver bug gets introduced. Every
    // clock read sits inside `if constexpr (Profile)`; none of them moves a line of real work.
    const auto solve_island_impl = [&]<bool Profile>(std::size_t k) {
        if (active[k] == 0) {
            return; // wholly asleep — its bodies stay frozen
        }
        const std::uint32_t cb = isl.constraint_offsets[k];
        const std::uint32_t ce = isl.constraint_offsets[k + 1];
        const std::span<ContactConstraint> cs{ordered.data() + cb, ce - cb};

        // `whole` times the island end to end; `lap` is restarted at each phase boundary. Both are
        // read ON THE THREAD THAT SOLVES, and slot k is written by this island alone.
        // In the off instantiation both are an empty type, so not even the constructor's clock
        // read survives.
        struct NoClock {};
        using Clock = std::conditional_t<Profile, core::Stopwatch, NoClock>;
        [[maybe_unused]] Clock whole;
        [[maybe_unused]] Clock lap;
        [[maybe_unused]] const auto ns_of = [](const core::Stopwatch& w) {
            return static_cast<std::uint64_t>(w.elapsed_us() * 1000.0 + 0.5);
        };

        warm_start(bodies, cs);
        if constexpr (Profile) {
            p.island_solve_slots[k].warm_ns = ns_of(lap);
            lap.restart();
        }
        solve_velocities(bodies, cs, kVelocityIterations);
        if constexpr (Profile) {
            p.island_solve_slots[k].velocity_ns = ns_of(lap);
            lap.restart();
        }
        store_impulses(cs, manifolds); // writes only this island's manifold indices — disjoint
        if constexpr (Profile) {
            p.island_solve_slots[k].store_ns = ns_of(lap);
            lap.restart();
        }

        // Integrate this island's dynamic bodies with their post-solve velocities. Orientation
        // integrates by q̇ = ½·ω·q then renormalizes (docs/math/rigid-body-dynamics.md §3).
        for (std::uint32_t bi = isl.body_offsets[k]; bi < isl.body_offsets[k + 1]; ++bi) {
            const std::uint32_t i = isl.bodies[bi];
            p.position[i] += p.linear_velocity[i] * dt;
            const core::Vec3 w = p.angular_velocity[i];
            const core::Quat q = p.orientation[i];
            const core::Quat omega{w.x, w.y, w.z, 0.0f};
            p.orientation[i] = core::normalize(q + (omega * q) * (0.5f * dt));
        }

        // NGS position pass: recover residual penetration by adjusting poses only — never
        // velocities (the deliberate not-Baumgarte choice; solver.hpp, ADR-0026).
        solve_positions(bodies, cs, kPositionIterations);
        if constexpr (Profile) {
            // The position half = the integration loop above PLUS solve_positions, one bucket.
            p.island_solve_slots[k].position_ns = ns_of(lap);
            p.island_solve_slots[k].ns = ns_of(whole);
        }
    };
    const auto solve_island = [&](std::size_t k) {
        solve_island_impl.template operator()<false>(k);
    };

    const bool profile_islands = p.island_profile_enabled;
    if (profile_islands) {
        p.island_solve_slots.assign(isl.island_count,
                                    Impl::SolveSlot{}); // allocates only when profiling
    }
    // Island-profile timing: the `Profile = true` instantiation of the one solve body above. The
    // one `profile_islands` test is hoisted to the dispatch below, outside every per-island and
    // per-constraint loop, so the profile-off path hands out `solve_island` and carries no clock
    // call, no slot write and no branch.
    const auto solve_island_timed = [&](std::size_t k) {
        solve_island_impl.template operator()<true>(k);
    };

    // The dispatch below is the original, generic over which per-island callable it hands out.
    const auto dispatch_islands = [&](const auto& solve_one) {
        // The zone wraps the DISPATCH, on the calling thread — deliberately not inside
        // `solve_island`, which the job system runs on workers. The zone sink is one global slot
        // with no per-thread accumulation, so a zone on a worker would serialize the parallel
        // region it is measuring.
        {
            RIME_PROFILE_ZONE(p.zone(StepZone::Solve));
            // The gate is the ACTIVE island count, not the island count (m17.5). An asleep island
            // is a no-op inside solve_island, so a tick holding one awake pile beside fifty resting
            // ones has exactly one island's worth of work and no way to divide it — dispatching it
            // still costs a parallel_for's full wake-and-join across every worker, paid for
            // nothing. That case is not rare in a destruction scene: it is what most of a
            // collapse's aftermath looks like.
            if (p.jobs != nullptr && active_count > 1) {
                // Over-decompose to ~4 chunks per participant so work-stealing balances the (wildly
                // uneven) island sizes. Any chunking is correct — islands are independent — so the
                // RESULT never depends on the chunk size or the worker count, only the timing does.
                // Chunked over ALL islands, because solve_island is indexed by island: the asleep
                // ones return immediately and work-stealing absorbs the empty chunks.
                const std::size_t participants = p.jobs->participant_count();
                const std::size_t chunk = std::max<std::size_t>(
                    1, (isl.island_count + participants * 4 - 1) / (participants * 4));
                p.jobs->parallel_for(isl.island_count, chunk, solve_one);
                p.parallel_islands_last = static_cast<std::uint32_t>(active_count);
            } else {
                for (std::size_t k = 0; k < isl.island_count; ++k) {
                    solve_one(k);
                }
                p.parallel_islands_last = 0;
            }
        } // physics.solve
    };
    if (profile_islands) {
        dispatch_islands(solve_island_timed);
    } else {
        dispatch_islands(solve_island);
    }

    // ---- 7. Update SLEEPING, measured on the POST-solve velocities (a resting body's pre-solve
    // velocity still holds the g·dt its contact just cancelled, so only now is it near rest) and
    // on the POST-NGS poses. Each active island's bodies accrue sleep time by EITHER of two
    // routes — speed under the thresholds, or a pose that has not left its rest envelope (both in
    // islands.hpp) — and lose it the instant they break the one they were accruing on. Once every
    // member has earned candidacy for kTimeToSleep the whole island sleeps: velocities zeroed, and
    // from next tick skipped. Sequential and deterministic, so sleeping never perturbs the
    // cross-thread world hash. Note that world_hash() covers poses and velocities but NOT this
    // bookkeeping, so the cross-worker bit-identity test observes the consequences of a sleep
    // decision and not the decision itself.
    if (p.sleeping_enabled) {
        RIME_PROFILE_ZONE(p.zone(StepZone::Sleep));
        constexpr float lin2 = kLinearSleepThreshold * kLinearSleepThreshold;
        constexpr float ang2 = kAngularSleepThreshold * kAngularSleepThreshold;
        for (std::size_t k = 0; k < isl.island_count; ++k) {
            if (active[k] == 0) {
                continue;
            }
            bool island_can_sleep = true;
            for (std::uint32_t bi = isl.body_offsets[k]; bi < isl.body_offsets[k + 1]; ++bi) {
                const std::uint32_t i = isl.bodies[bi];
                const bool sleepy = core::dot(p.linear_velocity[i], p.linear_velocity[i]) < lin2 &&
                                    core::dot(p.angular_velocity[i], p.angular_velocity[i]) < ang2;
                p.sleep_timer[i] = sleepy ? p.sleep_timer[i] + dt : 0.0f;

                // The second route, on the POST-NGS pose (islands.hpp): has the body actually
                // GONE anywhere? Velocity is sampled once per step and a settling pile's chunks
                // get kicked above the bound every few ticks while moving micrometres, so the
                // speed route alone keeps such a pile awake forever. On a violation the anchor is
                // re-pinned here rather than crept, so the envelope measures total displacement
                // from one pose and not a sliding window that drift can walk through.
                if (pose_within_rest_envelope(p.position[i],
                                              p.orientation[i],
                                              p.rest_anchor_position[i],
                                              p.rest_anchor_orientation[i])) {
                    p.pose_rest_timer[i] += dt;
                } else {
                    p.pose_rest_timer[i] = 0.0f;
                    p.rest_anchor_position[i] = p.position[i];
                    p.rest_anchor_orientation[i] = p.orientation[i];
                }

                // EITHER route earns this body its candidacy; the island still needs every member
                // to have earned it, which is what keeps a stack from half-sleeping.
                if (p.sleep_timer[i] < kTimeToSleep && p.pose_rest_timer[i] < kTimeToSleep) {
                    island_can_sleep = false;
                }
            }
            if (island_can_sleep) {
                for (std::uint32_t bi = isl.body_offsets[k]; bi < isl.body_offsets[k + 1]; ++bi) {
                    const std::uint32_t i = isl.bodies[bi];
                    p.asleep[i] = 1;
                    p.linear_velocity[i] = core::Vec3{0.0f, 0.0f, 0.0f};
                    p.angular_velocity[i] = core::Vec3{0.0f, 0.0f, 0.0f};
                }
            }
        }
    }

    // ---- 7.5 Emit contact & sleep events (M7.9, events.hpp). A pure read of the state the solve
    // just produced, in the sequential tail: the parallel_for above has joined, so the manifolds'
    // impulses are settled and reading them is race-free; nothing here writes body state, so the
    // world hash and cross-thread determinism are untouched. The event STREAM is itself bit-
    // identical for any worker count — it derives only from the canonical manifolds and the
    // (thread- count-independent) solved impulses and sleep decisions.

    // Build this tick's contact records from the SOLVED manifolds, in their canonical order —
    // one record per contact REGION (pair + child sub-pair; plain pairs are one region, M7.12).
    // Skip a pair with no dynamic member (an immovable pair exchanges no impulse — nothing to
    // report). A region that has a dynamic member but whose every dynamic member is now asleep is
    // recorded `suppressed`: kept present (so it is not falsely reported as Ended — an asleep pair
    // never separated) but emitting no event, which is what makes a settled pile silent.
    {
        RIME_PROFILE_ZONE(p.zone(StepZone::Events));
        p.contact_cur.clear();
        for (const Manifold& m : manifolds) {
            const std::uint32_t da = p.dense_of(m.a);
            const std::uint32_t db = p.dense_of(m.b);
            if (da == core::kInvalidSlotIndex || db == core::kInvalidSlotIndex) {
                continue; // defensive: build_contacts only emits live pairs
            }
            const bool is_trigger = p.sensor[da] != 0 || p.sensor[db] != 0;
            // A CONTACT needs a dynamic member — an immovable pair exchanges no impulse, so there
            // is nothing to report. A TRIGGER does not: overlap is the whole event, and the
            // archetypal case is a STATIC volume watching for a KINEMATIC character, where both
            // inverse masses are zero. Dropping trigger pairs here was silent — the volume simply
            // never fired — and it is the reason this exception is spelled out rather than folded
            // into the condition (m15.6).
            if (!is_trigger && p.inv_mass[da] + p.inv_mass[db] <= 0.0f) {
                continue; // no dynamic member — not an evented contact
            }
            // Representative point = the deepest (first max, strict >, so ties resolve
            // deterministically); impulses = the region's total exchanged momentum this tick.
            std::uint8_t best = 0;
            float normal_impulse = 0.0f;
            float tangent_impulse = 0.0f;
            for (std::uint8_t k = 0; k < m.count; ++k) {
                if (m.points[k].penetration > m.points[best].penetration) {
                    best = k;
                }
                normal_impulse += m.points[k].normal_impulse;
                tangent_impulse += m.points[k].tangent_impulse;
            }
            const bool awake_dyn_a = p.inv_mass[da] > 0.0f && p.asleep[da] == 0;
            const bool awake_dyn_b = p.inv_mass[db] > 0.0f && p.asleep[db] == 0;
            p.contact_cur.push_back(Impl::ContactRecord{
                (static_cast<std::uint64_t>(m.a.index) << 32) |
                    static_cast<std::uint64_t>(m.b.index),
                (static_cast<std::uint32_t>(m.child_a) << 16) |
                    static_cast<std::uint32_t>(m.child_b),
                m.patch,
                m.a,
                m.b,
                m.points[best].position,
                m.normal,
                normal_impulse,
                tangent_impulse,
                // A TRIGGER IS NEVER SUPPRESSED, and that is a real difference rather than an
                // oversight. Contacts suppress a pair whose every dynamic member is asleep, because
                // a resting stack exchanging no new impulse has nothing to report. An overlap does
                // not stop being an overlap when the body inside it falls asleep — and, more to the
                // point, a KINEMATIC character has zero inverse mass and is never "an awake dynamic
                // member" at all, so the contact rule would silence exactly the case triggers exist
                // for.
                /*suppressed=*/is_trigger ? false : !(awake_dyn_a || awake_dyn_b),
                /*trigger=*/is_trigger});
        }

        // Classify by a linear merge of the two key-sorted lists (cur = this tick, prev = last
        // tick): a region only in cur is Began, only in prev is Ended, in both is Persisted. The
        // merge key is (pair key, child sub-pair) compared lexicographically — plain pairs all
        // carry sub-pair 0, so their merge is exactly the M7.9 pair merge. Suppressed cur records
        // still consume their merge position (so a matching prev record is not reported Ended) but
        // emit nothing. The result is naturally in canonical region order.
        p.contact_events_back.clear();
        p.trigger_events_back.clear();
        const auto emit_contact = [&](const Impl::ContactRecord& r, ContactPhase phase) {
            if (r.trigger) {
                // Same lifecycle, different family. A trigger carries only WHO and WHICH PHASE —
                // there is no contact point, no normal and no impulse to report, because nothing
                // was solved. Reporting a manifold's geometry here would hand a consumer numbers
                // that look like a contact and are not one.
                TriggerEvent t;
                t.a = r.a;
                t.b = r.b;
                t.phase = phase;
                t.child_a = static_cast<std::uint16_t>(r.children >> 16);
                t.child_b = static_cast<std::uint16_t>(r.children & 0xFFFFu);
                p.trigger_events_back.push_back(t);
                return;
            }
            ContactEvent e;
            e.a = r.a;
            e.b = r.b;
            e.point = r.point;
            e.normal = r.normal;
            // An Ended region exchanged nothing this tick; its record is last tick's, so ignore its
            // stored impulses and report zero.
            e.normal_impulse = phase == ContactPhase::Ended ? 0.0f : r.normal_impulse;
            e.tangent_impulse = phase == ContactPhase::Ended ? 0.0f : r.tangent_impulse;
            e.phase = phase;
            e.child_a = static_cast<std::uint16_t>(r.children >> 16);
            e.child_b = static_cast<std::uint16_t>(r.children & 0xFFFFu);
            e.patch = r.patch;
            p.contact_events_back.push_back(e);
        };
        const auto record_less = [](const Impl::ContactRecord& x, const Impl::ContactRecord& y) {
            // (pair, child sub-pair, terrain patch) lexicographically — the patch is 0 for every
            // non-terrain region, so their merge is unchanged (M19.1).
            if (x.key != y.key) {
                return x.key < y.key;
            }
            if (x.children != y.children) {
                return x.children < y.children;
            }
            return x.patch < y.patch;
        };
        {
            const std::vector<Impl::ContactRecord>& cur = p.contact_cur;
            const std::vector<Impl::ContactRecord>& prev = p.contact_prev;
            std::size_t i = 0;
            std::size_t j = 0;
            while (i < cur.size() && j < prev.size()) {
                if (record_less(cur[i], prev[j])) {
                    if (!cur[i].suppressed) {
                        emit_contact(cur[i], ContactPhase::Began);
                    }
                    ++i;
                } else if (record_less(prev[j], cur[i])) {
                    emit_contact(prev[j], ContactPhase::Ended);
                    ++j;
                } else {
                    if (!cur[i].suppressed) {
                        emit_contact(cur[i], ContactPhase::Persisted);
                    }
                    ++i;
                    ++j;
                }
            }
            for (; i < cur.size(); ++i) {
                if (!cur[i].suppressed) {
                    emit_contact(cur[i], ContactPhase::Began);
                }
            }
            for (; j < prev.size(); ++j) {
                emit_contact(prev[j], ContactPhase::Ended);
            }
        }
        p.contact_prev.swap(p.contact_cur); // this tick becomes next tick's baseline

        // Sleep/wake events: the bodies whose sleep state changed during this step, in dense order.
        p.sleep_events_back.clear();
        for (std::size_t i = 0; i < n; ++i) {
            if (p.asleep_snapshot[i] == p.asleep[i]) {
                continue;
            }
            SleepEvent e;
            e.body = BodyId{p.dense_to_slot[i], p.slots[p.dense_to_slot[i]].generation};
            e.phase = p.asleep[i] != 0 ? SleepPhase::Slept : SleepPhase::Woke;
            p.sleep_events_back.push_back(e);
        }

        // Publish: swap the filled back buffers to front, so the accessors return this tick's
        // events, stable until the next step() refills and swaps again (the double buffer).
        p.contact_events_front.swap(p.contact_events_back);
        p.trigger_events_front.swap(p.trigger_events_back);
        p.sleep_events_front.swap(p.sleep_events_back);
    } // physics.events

    // ---- 8. Commit the contact cache from the SOLVED manifolds (closing the warm-start loop),
    // then refit the broadphase proxy of every body that actually moved — the dynamic members of
    // ACTIVE islands (which includes any body that only just went to sleep this tick). Asleep
    // islands did not move, so their proxies and the tree are left untouched; move_proxy mutates
    // the shared tree, so this stays sequential.
    {
        RIME_PROFILE_ZONE(p.zone(StepZone::Commit));
        p.commit_contact_cache(manifolds);
        for (std::size_t k = 0; k < isl.island_count; ++k) {
            if (active[k] == 0) {
                continue;
            }
            for (std::uint32_t bi = isl.body_offsets[k]; bi < isl.body_offsets[k + 1]; ++bi) {
                const std::uint32_t i = isl.bodies[bi];
                const Aabb tight = p.aabb_of(p.shape[i], p.position[i], p.orientation[i]);
                p.dynamic_tree.move_proxy(p.proxy[i], tight);
            }
        }
    }

    // ---- 9. Collect the tick's instrument panel (M7.13, WorldStats). A pure read of the state the
    // pipeline just produced — body population, collision load, island structure — as deterministic
    // counts: it never touches body state, so the world hash and cross-thread determinism are
    // untouched, and the numbers themselves are thread-count-invariant (they derive only from the
    // canonical manifolds and the pure-function island partition). Cheap: one O(n) pass over the
    // bodies plus the O(manifolds)/O(islands) walks the tick already made.
    RIME_PROFILE_ZONE(p.zone(StepZone::Stats));
    WorldStats& st = p.last_stats;
    st = WorldStats{};
    st.body_count = static_cast<std::uint32_t>(n);
    for (std::size_t i = 0; i < n; ++i) {
        switch (static_cast<MotionType>(p.motion[i])) {
            case MotionType::Dynamic:
                ++st.dynamic_bodies;
                if (p.asleep[i] != 0) {
                    ++st.sleeping_bodies;
                } else {
                    ++st.awake_bodies;
                }
                break;
            case MotionType::Static:
                ++st.static_bodies;
                break;
            case MotionType::Kinematic:
                ++st.kinematic_bodies;
                break;
        }
    }
    st.broadphase_pairs = p.broadphase_pairs_last;
    st.manifolds = static_cast<std::uint32_t>(manifolds.size());
    for (const Manifold& m : manifolds) {
        st.contact_points += m.count;
    }
    // Terrain regions are the manifolds whose pair has a heightfield on either side (M19.1).
    for (const Manifold& m : manifolds) {
        const std::uint32_t ma = p.dense_of(m.a);
        const std::uint32_t mb = p.dense_of(m.b);
        if ((ma != core::kInvalidSlotIndex && p.shape[ma].type == ShapeType::Heightfield) ||
            (mb != core::kInvalidSlotIndex && p.shape[mb].type == ShapeType::Heightfield)) {
            ++st.heightfield_manifolds;
        }
    }
    st.heightfield_patch_merges = p.hf_patch_merges_last;
    st.heightfield_ccd_skipped = p.hf_ccd_skipped_last;
    st.contacts_warm_started = p.warm_started_last;
    st.islands = static_cast<std::uint32_t>(isl.island_count);
    st.islands_solved_parallel = p.parallel_islands_last;
    for (std::size_t k = 0; k < isl.island_count; ++k) {
        const std::uint32_t sz = isl.body_offsets[k + 1] - isl.body_offsets[k];
        st.largest_island = std::max(st.largest_island, sz);
        if (active[k] != 0) {
            ++st.active_islands;
            st.largest_active_island = std::max(st.largest_active_island, sz);
        }
    }

    // ---- Island solve cost (opt-in; see WorldStats::island_solve_ns_total). Sequential, after the
    // join, reading the per-island slots the workers wrote — so it adds nothing to the parallel
    // region and cannot touch body state.
    if (profile_islands) {
        p.island_profile.clear();
        std::size_t big = isl.island_count; // biggest-by-bodies active island (lowest id on a tie)
        std::uint32_t big_bodies = 0;
        for (std::size_t k = 0; k < isl.island_count; ++k) {
            if (active[k] == 0) {
                continue;
            }
            const std::uint32_t nb = isl.body_offsets[k + 1] - isl.body_offsets[k];
            const std::uint64_t ns = p.island_solve_slots[k].ns;
            p.island_profile.push_back(
                IslandSolveCost{static_cast<std::uint32_t>(k),
                                nb,
                                isl.constraint_offsets[k + 1] - isl.constraint_offsets[k],
                                ns,
                                p.island_solve_slots[k].warm_ns,
                                p.island_solve_slots[k].velocity_ns,
                                p.island_solve_slots[k].store_ns,
                                p.island_solve_slots[k].position_ns});
            st.island_solve_ns_total += ns;
            st.largest_active_island_solve_ns = std::max(st.largest_active_island_solve_ns, ns);
            if (nb > big_bodies) {
                big_bodies = nb;
                big = k;
            }
        }
        if (big < isl.island_count) {
            // Membership fingerprint: FNV-1a over the island's (dense-sorted) body indices.
            const std::span<const std::uint32_t> members{isl.bodies.data() + isl.body_offsets[big],
                                                         big_bodies};
            const std::uint64_t h = core::fnv1a_64(std::as_bytes(members));
            st.largest_island_prev_bodies = p.prev_largest_valid ? p.prev_largest_bodies : 0;
            st.largest_island_membership_changed =
                p.prev_largest_valid &&
                (p.prev_largest_bodies != big_bodies || p.prev_largest_hash != h);
            p.prev_largest_valid = true;
            p.prev_largest_bodies = big_bodies;
            p.prev_largest_hash = h;
        } else {
            p.prev_largest_valid = false; // nothing solved: no previous island to compare against
        }
    }
}

void PhysicsWorld::compute_pairs(std::vector<Pair>& out) const {
    impl_->compute_pairs(out);
}

bool PhysicsWorld::broadphase_aabb(BodyId id, Aabb& out) const {
    const std::uint32_t d = impl_->dense_of(id);
    if (d == core::kInvalidSlotIndex) {
        return false;
    }
    out = impl_->tree_for(impl_->motion[d]).proxy_aabb(impl_->proxy[d]);
    return true;
}

bool PhysicsWorld::validate_broadphase() const {
    return impl_->dynamic_tree.validate() && impl_->static_tree.validate();
}

void PhysicsWorld::compute_contacts(std::vector<Manifold>& out) const {
    // The test/inspection seam: same collision path as step(), but with no solver in between the
    // build and the commit — the cache carries forward whatever the manifolds were warm-started
    // with (zeros on a fresh world, or the last step()'s solved impulses, unchanged either way).
    impl_->build_contacts(out);
    impl_->commit_contact_cache(out);
}

std::uint32_t PhysicsWorld::contacts_warm_started_last() const noexcept {
    return impl_->warm_started_last;
}

void PhysicsWorld::set_profile_label(std::string_view label) {
    impl_->set_zone_label(label);
}

void PhysicsWorld::set_job_system(core::JobSystem* jobs) noexcept {
    // Borrowed, not owned — the engine constructs one job system and hands it to every subsystem.
    // Null restores the sequential island solve (identical result, just single-threaded).
    impl_->jobs = jobs;
}

void PhysicsWorld::set_sleeping_enabled(bool enabled) noexcept {
    impl_->sleeping_enabled = enabled;
    if (!enabled) {
        // Wake everything now so step() never skips a body while sleeping is off (and a body frozen
        // by an earlier sleep resumes integrating on the very next tick).
        std::fill(impl_->asleep.begin(), impl_->asleep.end(), std::uint8_t{0});
        for (std::size_t i = 0; i < impl_->sleep_timer.size(); ++i) {
            impl_->clear_rest(i);
        }
    }
}

bool PhysicsWorld::is_asleep(BodyId id) const noexcept {
    const std::uint32_t d = impl_->dense_of(id);
    return d != core::kInvalidSlotIndex && impl_->asleep[d] != 0;
}

void PhysicsWorld::wake_body(BodyId id) noexcept {
    const std::uint32_t d = impl_->dense_of(id);
    if (d == core::kInvalidSlotIndex) {
        return; // stale/unknown — safe no-op
    }
    impl_->asleep[d] = 0;
    impl_->clear_rest(d);
    // The rest of its island reactivates on the next step(): stage 5 sees an awake member and wakes
    // the others. (Waking the whole island here would need the island partition, which step()
    // owns.)
}

void PhysicsWorld::set_island_profile_enabled(bool enabled) noexcept {
    impl_->island_profile_enabled = enabled;
    impl_->prev_largest_valid = false; // a gap in profiled steps makes the old island no comparison
    if (!enabled) {
        impl_->island_profile.clear();
    }
}

bool PhysicsWorld::island_profile_enabled() const noexcept {
    return impl_->island_profile_enabled;
}

std::span<const IslandSolveCost> PhysicsWorld::island_solve_profile_last() const noexcept {
    return impl_->island_profile;
}

void PhysicsWorld::set_contact_profile_enabled(bool enabled) noexcept {
    impl_->contact_profile_enabled = enabled;
    if (!enabled) {
        impl_->contact_profile_last = {};
    }
}

bool PhysicsWorld::contact_profile_enabled() const noexcept {
    return impl_->contact_profile_enabled;
}

const ContactProfile& PhysicsWorld::contact_profile() const noexcept {
    return impl_->contact_profile_last;
}

void PhysicsWorld::set_plain_contact_cull_enabled(bool enabled) noexcept {
    impl_->plain_contact_cull_enabled = enabled;
}

bool PhysicsWorld::plain_contact_cull_enabled() const noexcept {
    return impl_->plain_contact_cull_enabled;
}

std::size_t PhysicsWorld::islands_last() const noexcept {
    return impl_->last_stats.islands;
}

WorldStats PhysicsWorld::stats() const noexcept {
    return impl_->last_stats;
}

std::uint64_t PhysicsWorld::world_hash() const noexcept {
    // FNV-1a (core/hash.hpp) over the full motion state of every body, in dense order — a fast
    // exact equality fingerprint. Dense order is reproducible run to run (bodies are appended, and
    // only ever swap-removed by destroy_body, never reordered by a step), so two simulations that
    // issued the same calls hash identically iff every float matches bit for bit. That is exactly
    // the check the parallel step must pass at any worker count, and the hook netcode / replay
    // determinism reuses. Packed into a local array so the hash never depends on Vec3/Quat
    // alignment padding.
    const Impl& p = *impl_;
    std::uint64_t h = core::kFnv1a64OffsetBasis;
    for (std::size_t i = 0; i < p.count(); ++i) {
        const std::array<float, 13> state = {
            p.position[i].x,
            p.position[i].y,
            p.position[i].z,
            p.orientation[i].x,
            p.orientation[i].y,
            p.orientation[i].z,
            p.orientation[i].w,
            p.linear_velocity[i].x,
            p.linear_velocity[i].y,
            p.linear_velocity[i].z,
            p.angular_velocity[i].x,
            p.angular_velocity[i].y,
            p.angular_velocity[i].z,
        };
        h = core::fnv1a_64(std::as_bytes(std::span<const float>{state}), h);
    }
    return h;
}

bool PhysicsWorld::raycast(const Ray& ray, RayHit& out, const QueryFilter& filter) const {
    const Impl& p = *impl_;
    const float dir_len = core::length(ray.direction);
    if (dir_len < 1e-8f) {
        return false; // a zero-length ray hits nothing
    }
    const core::Vec3 dir = ray.direction / dir_len; // unit ⇒ the reported t is a world distance
    const float tmax = ray.max_distance;

    float best_t = tmax;
    std::uint32_t best_slot = core::kInvalidSlotIndex;
    core::Vec3 best_n{0.0f, 0.0f, 0.0f};
    std::uint16_t best_child = 0;

    // A reported leaf's slot is live (it is in the tree), so slots[slot].dense is its current row.
    // Pass the running `best_t` as the exact test's bound so a farther candidate is rejected
    // cheaply; the nearest survivor across both trees wins.
    const auto test = [&](std::uint32_t slot) {
        if (p.is_excluded(filter, slot)) {
            return;
        }
        const std::uint32_t d = p.slots[slot].dense;
        float t = 0.0f;
        core::Vec3 n{0.0f, 0.0f, 0.0f};
        std::uint16_t child = 0;
        // Terrain takes its own grid walk (heightfield.hpp) — it needs the store entry the
        // shape-only ray_vs_shape dispatch cannot see (M19.1).
        if (const HeightfieldShape* hf = p.heightfield_of(p.shape[d]); hf != nullptr) {
            if (ray_vs_heightfield(
                    *hf, p.position[d], p.orientation[d], ray.origin, dir, best_t, t, n) &&
                t < best_t) {
                best_t = t;
                best_slot = slot;
                best_n = n;
                best_child = 0;
            }
            return;
        }
        if (ray_vs_shape(p.shape[d],
                         p.position[d],
                         p.orientation[d],
                         ray.origin,
                         dir,
                         best_t,
                         t,
                         n,
                         p.hull_of(p.shape[d]),
                         p.compound_of(p.shape[d]),
                         p.hull_span(),
                         &child) &&
            t < best_t) {
            best_t = t;
            best_slot = slot;
            best_n = n;
            best_child = child;
        }
    };

    // Each tree carries exactly one filter class — the dynamic tree is dynamic+kinematic, the
    // static tree is static — so a filter flag simply gates a whole tree; no per-leaf motion check
    // needed.
    if (filter.dynamics) {
        p.dynamic_tree.query_ray(ray.origin, dir, tmax, test);
    }
    if (filter.statics) {
        p.static_tree.query_ray(ray.origin, dir, tmax, test);
    }

    if (best_slot == core::kInvalidSlotIndex) {
        return false;
    }
    out.body = BodyId{best_slot, p.slots[best_slot].generation};
    out.point = ray.origin + dir * best_t;
    out.normal = best_n;
    out.distance = best_t;
    out.child = best_child; // which compound child was pierced (0 for a plain body) — M8.3
    return true;
}

bool PhysicsWorld::shape_cast(const ShapeCast& cast,
                              ShapeHit& out,
                              const QueryFilter& filter) const {
    const Impl& p = *impl_;

    // A compound caster has no single support function (it is not convex), which is the same reason
    // the CCD path refuses one — see the speculative-contact branch above.
    if (cast.shape.type == ShapeType::Compound) {
        return false;
    }
    // A finite, positive distance is a precondition rather than a nicety: the broadphase step
    // queries the SWEPT AABB, and an unbounded sweep's box is the whole world — which would turn an
    // O(log n) query into a scan of every body without saying so.
    if (!(cast.max_distance > 0.0f) || !std::isfinite(cast.max_distance)) {
        return false;
    }
    const float dir_len = core::length(cast.direction);
    if (dir_len < 1e-8f) {
        return false; // a zero-length sweep touches nothing (use overlap_sphere for "am I inside?")
    }
    const core::Vec3 dir = cast.direction / dir_len; // unit ⇒ the reported distance is world units
    const float tmax = cast.max_distance;

    const ConvexHull* caster_hull = p.hull_of(cast.shape);

    // The swept bound: the caster's box at both ends of the sweep, unioned. Every body that could
    // possibly be touched has a fat AABB overlapping this, so the BVH can reject the rest.
    const Aabb start_box = p.aabb_of(cast.shape, cast.origin, cast.orientation);
    const Aabb end_box = p.aabb_of(cast.shape, cast.origin + dir * tmax, cast.orientation);
    const Aabb swept{core::Vec3{std::min(start_box.min.x, end_box.min.x),
                                std::min(start_box.min.y, end_box.min.y),
                                std::min(start_box.min.z, end_box.min.z)},
                     core::Vec3{std::max(start_box.max.x, end_box.max.x),
                                std::max(start_box.max.y, end_box.max.y),
                                std::max(start_box.max.z, end_box.max.z)}};

    float best_t = tmax;
    std::uint32_t best_slot = core::kInvalidSlotIndex;
    core::Vec3 best_n{0.0f, 0.0f, 0.0f};
    core::Vec3 best_p{0.0f, 0.0f, 0.0f};
    std::uint16_t best_child = 0;
    bool best_overlap = false;

    // One candidate body. A compound is opened one level (children are never compounds — the same
    // rule the raycast follows) so the reported child names the destructible PART that was caught.
    const auto test = [&](std::uint32_t slot) {
        if (p.is_excluded(filter, slot)) {
            return;
        }
        const std::uint32_t d = p.slots[slot].dense;
        const ShapeDesc& shape = p.shape[d];
        if (shape.type == ShapeType::Heightfield) {
            // Terrain takes the per-triangle cast (m19.2): the heightfield has no support function
            // of its own, so the sweep is run against each candidate CELL TRIANGLE, which is
            // convex, through the very same `cast_convex_vs_convex` every other target uses. The
            // query is transformed into the tile's frame and the answer rotated back out — an
            // isometry, so the reported distance is unchanged by the trip.
            const HeightfieldShape* hf = p.heightfield_of(shape);
            if (hf == nullptr) {
                p.hf_query_skips.fetch_add(1, std::memory_order_relaxed);
                return;
            }
            const core::Vec3 tp = p.position[d];
            const core::Quat tqc = core::conjugate(p.orientation[d]);
            float t = 0.0f;
            core::Vec3 n{};
            core::Vec3 pt{};
            bool overlap = false;
            bool truncated = false;
            const bool got = cast_shape_vs_heightfield_local(*hf,
                                                             cast.shape,
                                                             core::rotate(tqc, cast.origin - tp),
                                                             tqc * cast.orientation,
                                                             caster_hull,
                                                             core::rotate(tqc, dir),
                                                             tmax,
                                                             t,
                                                             n,
                                                             pt,
                                                             overlap,
                                                             truncated);
            if (truncated) {
                // The candidate bound exceeded the per-query triangle budget, so this answer is
                // about PART of the tile. Counted on the same counter M19.1 used, because the
                // meaning is the same one: the cast could not look at everything. Whatever it DID
                // find is still reported — a real hit is not made less true by an incomplete
                // search, and suppressing it would turn a conservative answer into a wrong one.
                p.hf_query_skips.fetch_add(1, std::memory_order_relaxed);
            }
            if (overlap && !best_overlap) {
                best_t = 0.0f;
                best_slot = slot;
                best_n = core::rotate(p.orientation[d], n);
                best_p = tp + core::rotate(p.orientation[d], pt);
                best_child = 0;
                best_overlap = true;
                return;
            }
            if (!got || best_overlap || t >= best_t) {
                return;
            }
            best_t = t;
            best_slot = slot;
            best_n = core::rotate(p.orientation[d], n);
            best_p = tp + core::rotate(p.orientation[d], pt);
            best_child = 0;
            return;
        }
        const core::Vec3 pos = p.position[d];
        const core::Quat& orient = p.orientation[d];

        const auto try_one = [&](const ShapeDesc& target_shape,
                                 core::Vec3 target_pos,
                                 const core::Quat& target_orient,
                                 const ConvexHull* target_hull,
                                 std::uint16_t child_index) {
            const ShapeSupport target{&target_shape, target_pos, target_orient, target_hull};
            float t = 0.0f;
            core::Vec3 n{0.0f, 0.0f, 0.0f};
            core::Vec3 pt{0.0f, 0.0f, 0.0f};
            bool overlap = false;
            if (!cast_convex_vs_convex(cast.shape,
                                       cast.origin,
                                       cast.orientation,
                                       caster_hull,
                                       target,
                                       target_pos,
                                       dir,
                                       best_t,
                                       t,
                                       n,
                                       pt,
                                       overlap)) {
                return;
            }
            // An INITIAL OVERLAP wins outright over any later touch, whatever its distance. It has
            // to: distance 0 is already minimal, and a caller that must depenetrate needs to hear
            // about the body it is inside rather than about a wall it would have reached later.
            if (overlap && !best_overlap) {
                best_t = 0.0f;
                best_slot = slot;
                best_n = n;
                best_p = pt;
                best_child = child_index;
                best_overlap = true;
                return;
            }
            if (best_overlap || t >= best_t) {
                return;
            }
            best_t = t;
            best_slot = slot;
            best_n = n;
            best_p = pt;
            best_child = child_index;
        };

        if (const CompoundShape* c = p.compound_of(shape); c != nullptr) {
            for (std::size_t i = 0; i < c->child_count(); ++i) {
                try_one(c->child_shape[i],
                        compound_child_world_pos(*c, i, pos, orient),
                        compound_child_world_orient(*c, i, orient),
                        compound_child_hull(c->child_shape[i], p.hull_span()),
                        static_cast<std::uint16_t>(i));
            }
            return;
        }
        try_one(shape, pos, orient, p.hull_of(shape), 0);
    };

    // Each tree carries exactly one filter class, so a flag gates a whole tree — the same structure
    // raycast() uses.
    if (filter.dynamics) {
        p.dynamic_tree.query(swept, test);
    }
    if (filter.statics) {
        p.static_tree.query(swept, test);
    }

    if (best_slot == core::kInvalidSlotIndex) {
        return false;
    }
    out.body = BodyId{best_slot, p.slots[best_slot].generation};
    out.point = best_p;
    out.normal = best_n;
    out.distance = best_overlap ? 0.0f : best_t;
    out.initial_overlap = best_overlap;
    out.child = best_child;
    return true;
}

bool PhysicsWorld::penetration(const ShapeDesc& shape,
                               core::Vec3 position,
                               core::Quat orientation,
                               PenetrationHit& out,
                               const QueryFilter& filter) const {
    const Impl& p = *impl_;

    // A compound QUERY shape has no support function (it is not convex), the same refusal
    // shape_cast and the CCD path make. Compound BODIES are fine — they are opened below.
    if (shape.type == ShapeType::Compound) {
        return false;
    }
    const ConvexHull* query_hull = p.hull_of(shape);
    if (shape.type == ShapeType::ConvexHull && query_hull == nullptr) {
        return false; // an unresolvable hull id describes no geometry
    }

    // Broadphase cull by the query shape's own tight box. Leaves carry FAT boxes, so a tight query
    // box can only over-report — every genuinely overlapping body is found, and the extras are
    // thrown out by the exact GJK test below.
    const Aabb query_box = p.aabb_of(shape, position, orientation);

    float best_depth = -1.0f;
    core::Vec3 best_normal{0.0f, 1.0f, 0.0f};
    std::uint32_t best_slot = core::kInvalidSlotIndex;
    std::uint16_t best_child = 0;

    const auto test = [&](std::uint32_t slot) {
        if (p.is_excluded(filter, slot)) {
            return;
        }
        const std::uint32_t d = p.slots[slot].dense;
        const ShapeDesc& body_shape = p.shape[d];
        if (body_shape.type == ShapeType::Heightfield) {
            // Terrain takes the per-triangle GJK+EPA (m19.2), the same two kernels every convex
            // target uses, run against each candidate cell triangle and reduced by the same
            // "deepest wins" rule. The query is measured in the tile's frame and the axis rotated
            // back out.
            const HeightfieldShape* hf = p.heightfield_of(body_shape);
            if (hf == nullptr) {
                p.hf_query_skips.fetch_add(1, std::memory_order_relaxed);
                return;
            }
            const core::Vec3 tp = p.position[d];
            const core::Quat& tq = p.orientation[d];
            const core::Quat tqc = core::conjugate(tq);
            float depth = 0.0f;
            core::Vec3 axis{};
            core::Vec3 point{};
            bool truncated = false;
            const bool got = penetration_vs_heightfield_local(*hf,
                                                              shape,
                                                              core::rotate(tqc, position - tp),
                                                              tqc * orientation,
                                                              query_hull,
                                                              depth,
                                                              axis,
                                                              point,
                                                              truncated);
            if (truncated) {
                // Partial look, counted — the same meaning as the cast's truncation. What was
                // found is still reported: a measured overlap does not become less real because
                // a deeper one might exist in the part of the tile that was not reached.
                p.hf_query_skips.fetch_add(1, std::memory_order_relaxed);
            }
            if (!got) {
                return;
            }
            const bool better = best_slot == core::kInvalidSlotIndex || depth > best_depth ||
                                (depth == best_depth && slot < best_slot);
            if (!better) {
                return;
            }
            best_depth = depth;
            best_normal = core::rotate(tq, axis);
            best_slot = slot;
            best_child = 0;
            return;
        }
        const core::Vec3 body_pos = p.position[d];
        const core::Quat& body_orient = p.orientation[d];

        const ShapeSupport query{&shape, position, orientation, query_hull};

        const auto try_one = [&](const ShapeDesc& target_shape,
                                 core::Vec3 target_pos,
                                 const core::Quat& target_orient,
                                 const ConvexHull* target_hull,
                                 std::uint16_t child_index) {
            const ShapeSupport target{&target_shape, target_pos, target_orient, target_hull};

            // GJK first, exactly as the narrowphase does: it answers "do they overlap at all"
            // cheaply and, when they do, hands EPA the terminal simplex to start expanding from.
            // EPA is only ever run on a simplex GJK already proved encloses the origin.
            const GjkResult g = gjk(query, target, position - target_pos);
            if (!g.overlapping) {
                return;
            }
            const EpaResult e = epa(query, target, g.simplex, g.simplex_count);
            if (!e.valid) {
                // A numerically flat Minkowski difference — EPA's documented give-up. The
                // narrowphase drops the contact for the tick; here we drop the candidate. Saying
                // "no penetration" about a pair we could not measure is the honest answer: a
                // fabricated axis would teleport the caller somewhere arbitrary.
                return;
            }
            if (!(e.depth > 0.0f)) {
                // ZERO DEPTH IS NOT A PENETRATION, and enforcing that is not pedantry — it is what
                // keeps this query's answer meaning what its name says. EPA returns depth 0 when
                // the origin sits ON the Minkowski difference's boundary, i.e. the shapes touch
                // but do not overlap. There is nothing to push out of, and no direction that
                // could be measured from a boundary case anyway.
                //
                // It is also the shape a FALSE positive takes. GJK's overlap test is a
                // predicate, and its tolerance scales with the support extent it is comparing
                // against, so against a large target (a 60 m ramp, an arena floor) a shape a
                // centimetre clear can still trip it — measured here at m12.2, on a capsule
                // 1.7 cm above a ramp. When that happens EPA immediately reports depth 0,
                // because there genuinely is no overlap to expand into. Filtering on the
                // MEASUREMENT rather than on the predicate turns that whole class of false
                // positive into the correct answer, without this query needing an opinion about
                // GJK's epsilons. (The predicate's own accuracy is tracked separately —
                // docs/ROADMAP.md.)
                return;
            }

            // Deepest wins, with an EXACT-tie break toward the lower slot then the lower child, so
            // the answer never depends on which broadphase tree got walked first or how the BVH
            // happens to be shaped. (Deepest, not nearest: a body wedged between two walls must
            // resolve the worse violation first, and repeatedly resolving the deepest one strictly
            // reduces the maximum, so the recovery converges.)
            const bool better =
                best_slot == core::kInvalidSlotIndex || e.depth > best_depth ||
                (e.depth == best_depth &&
                 (slot < best_slot || (slot == best_slot && child_index < best_child)));
            if (!better) {
                return;
            }
            best_depth = e.depth;
            // EpaResult::normal separates by pushing B (the target) along it. The caller of THIS
            // query is the query shape — it is the thing that has to move — so the reported normal
            // is the other way round.
            best_normal = -e.normal;
            best_slot = slot;
            best_child = child_index;
        };

        if (const CompoundShape* c = p.compound_of(body_shape); c != nullptr) {
            for (std::size_t i = 0; i < c->child_count(); ++i) {
                try_one(c->child_shape[i],
                        compound_child_world_pos(*c, i, body_pos, body_orient),
                        compound_child_world_orient(*c, i, body_orient),
                        compound_child_hull(c->child_shape[i], p.hull_span()),
                        static_cast<std::uint16_t>(i));
            }
            return;
        }
        try_one(body_shape, body_pos, body_orient, p.hull_of(body_shape), 0);
    };

    if (filter.dynamics) {
        p.dynamic_tree.query(query_box, test);
    }
    if (filter.statics) {
        p.static_tree.query(query_box, test);
    }

    if (best_slot == core::kInvalidSlotIndex) {
        return false;
    }
    out.body = BodyId{best_slot, p.slots[best_slot].generation};
    out.normal = best_normal;
    out.depth = best_depth;
    out.child = best_child;
    return true;
}

void PhysicsWorld::overlap_sphere(core::Vec3 center,
                                  float radius,
                                  std::vector<BodyId>& out,
                                  const QueryFilter& filter) const {
    const Impl& p = *impl_;
    out.clear();
    const core::Vec3 r3{radius, radius, radius};
    const Aabb box{center - r3, center + r3};

    std::vector<std::uint32_t> hits;
    const auto collect = [&](std::uint32_t slot) {
        if (p.is_excluded(filter, slot)) {
            return;
        }
        const std::uint32_t d = p.slots[slot].dense;
        if (const HeightfieldShape* hf = p.heightfield_of(p.shape[d]); hf != nullptr) {
            // Terrain: the same per-triangle sphere test the contact path runs, in its frame.
            const core::Quat qc = core::conjugate(p.orientation[d]);
            if (sphere_overlaps_heightfield_local(
                    *hf, core::rotate(qc, center - p.position[d]), radius)) {
                hits.push_back(slot);
            }
            return;
        }
        if (sphere_vs_shape(center,
                            radius,
                            p.shape[d],
                            p.position[d],
                            p.orientation[d],
                            p.hull_of(p.shape[d]),
                            p.compound_of(p.shape[d]),
                            p.hull_span())) {
            hits.push_back(slot);
        }
    };
    if (filter.dynamics) {
        p.dynamic_tree.query(box, collect);
    }
    if (filter.statics) {
        p.static_tree.query(box, collect);
    }
    // Sort by stable slot id so the reported set is order-deterministic run to run (a hash map /
    // tree traversal order must never leak into a result the game or replication sees).
    std::sort(hits.begin(), hits.end());
    out.reserve(hits.size());
    for (const std::uint32_t slot : hits) {
        out.push_back(BodyId{slot, p.slots[slot].generation});
    }
}

void PhysicsWorld::apply_impulse(BodyId id, core::Vec3 impulse, core::Vec3 point) noexcept {
    Impl& p = *impl_;
    const std::uint32_t d = p.dense_of(id);
    if (d == core::kInvalidSlotIndex || p.inv_mass[d] == 0.0f) {
        return; // stale, or immovable (static/kinematic) — an impulse cannot move it
    }
    p.linear_velocity[d] += impulse * p.inv_mass[d];
    // Angular part: I⁻¹(r × J), with I⁻¹ the world-space inverse inertia — the exact same
    // composed apply_inv_inertia the solver uses (principal rotation included, M7.11), so an
    // external push and a contact impulse rotate a body by identical math.
    const core::Vec3 r = point - p.position[d];
    p.angular_velocity[d] += apply_inv_inertia(
        p.orientation[d], p.inertia_principal[d], p.inv_inertia[d], core::cross(r, impulse));
    // A sleeping body ignores velocity until something wakes it, so an impulse must wake it (its
    // island reactivates on the next step, exactly as wake_body documents).
    p.asleep[d] = 0;
    p.clear_rest(d);
}

void PhysicsWorld::apply_central_impulse(BodyId id, core::Vec3 impulse) noexcept {
    Impl& p = *impl_;
    const std::uint32_t d = p.dense_of(id);
    if (d == core::kInvalidSlotIndex || p.inv_mass[d] == 0.0f) {
        return;
    }
    p.linear_velocity[d] += impulse * p.inv_mass[d]; // applied through the COM ⇒ no torque
    p.asleep[d] = 0;
    p.clear_rest(d);
}

HullId PhysicsWorld::register_hull(const HullDesc& desc) {
    // Validate + derive (planes, mass properties, principal axes) in one cold pass — see
    // build_convex_hull (src/hull.hpp) for the rules and the math. Nothing is stored on failure,
    // so a rejected registration leaves the world bit-identical to before the call.
    ConvexHull hull;
    if (!build_convex_hull(desc.vertices, desc.face_counts, desc.face_indices, hull)) {
        return HullId{}; // null id — HullId::is_valid() == false
    }
    Impl& p = *impl_;
    // Reuse a freed slot if one is waiting (LIFO — a pure function of the register/unregister call
    // sequence, so ids stay deterministic), else grow the store. A reused slot keeps the generation
    // unregister_hull already bumped; a fresh slot starts at generation 0.
    std::uint32_t index;
    if (!p.hull_free_list.empty()) {
        index = p.hull_free_list.back();
        p.hull_free_list.pop_back();
        p.hulls[index] = std::move(hull);
        p.hull_live[index] = 1;
        p.hull_refs[index] = 0;
    } else {
        index = static_cast<std::uint32_t>(p.hulls.size());
        p.hulls.push_back(std::move(hull));
        p.hull_generation.push_back(0);
        p.hull_live.push_back(1);
        p.hull_refs.push_back(0);
    }
    return HullId{index, p.hull_generation[index]};
}

bool PhysicsWorld::unregister_hull(HullId id) {
    Impl& p = *impl_;
    // Unknown / stale / already-freed ids are a safe no-op (return false) — never touch another
    // slot's state. A live-but-referenced hull is refused too: some body or compound still names
    // it, and freeing it would dangle that reference (the reject-if-referenced contract, ADR-0027).
    if (id.index >= p.hulls.size() || p.hull_generation[id.index] != id.generation ||
        p.hull_live[id.index] == 0) {
        return false;
    }
    if (p.hull_refs[id.index] != 0) {
        return false;
    }
    p.hull_live[id.index] = 0;
    ++p.hull_generation[id.index]; // any id still holding the old generation now reads dead
    p.hull_free_list.push_back(id.index);
    return true;
}

bool PhysicsWorld::hull_info(HullId id, HullInfo& out) const {
    const Impl& p = *impl_;
    if (id.index >= p.hulls.size() || p.hull_generation[id.index] != id.generation ||
        p.hull_live[id.index] == 0) {
        return false;
    }
    const ConvexHull& h = p.hulls[id.index];
    out.volume = h.volume;
    out.centroid = h.centroid_authored;
    out.inertia_per_mass = h.inertia_per_mass;
    out.principal_rotation = h.principal;
    return true;
}

CompoundId PhysicsWorld::register_compound(const CompoundDesc& desc) {
    Impl& p = *impl_;
    // Validate each hull child against the LIVE store (generation + not-freed) BEFORE composing:
    // build_compound resolves children by index alone (compound_child_hull is a bounds check), so a
    // child naming a freed or stale hull slot must be caught here, where the slot metadata lives. A
    // primitive child carries no hull id and is skipped.
    for (const CompoundChildDesc& child : desc.children) {
        if (child.shape.type == ShapeType::ConvexHull) {
            const HullId h = child.shape.hull;
            if (h.index >= p.hulls.size() || p.hull_generation[h.index] != h.generation ||
                p.hull_live[h.index] == 0) {
                return CompoundId{}; // a child names a hull this world does not have live
            }
        }
    }

    // Compose (COM, parallel-axis inertia, principal axes, re-centred child poses) in one cold pass
    // — see build_compound (src/compound.hpp) for the rules and the math
    // (docs/math/compound-mass-properties.md). Nothing is stored on failure, so a rejected
    // registration leaves the world bit-identical to before the call — the register_hull posture.
    CompoundShape compound;
    if (!build_compound(desc.children, p.hull_span(), compound)) {
        return CompoundId{}; // null id — CompoundId::is_valid() == false
    }
    // Reuse a freed slot LIFO (deterministic ids) or grow the store, mirroring register_hull.
    std::uint32_t index;
    if (!p.compound_free_list.empty()) {
        index = p.compound_free_list.back();
        p.compound_free_list.pop_back();
        p.compounds[index] = std::move(compound);
        p.compound_live[index] = 1;
        p.compound_refs[index] = 0;
    } else {
        index = static_cast<std::uint32_t>(p.compounds.size());
        p.compounds.push_back(std::move(compound));
        p.compound_generation.push_back(0);
        p.compound_live.push_back(1);
        p.compound_refs.push_back(0);
    }
    // The compound now holds a reference on each hull child — so unregister_hull will refuse to
    // free a hull this compound still needs. unregister_compound releases these again.
    for (const CompoundChildDesc& child : desc.children) {
        if (child.shape.type == ShapeType::ConvexHull) {
            ++p.hull_refs[child.shape.hull.index];
        }
    }
    return CompoundId{index, p.compound_generation[index]};
}

bool PhysicsWorld::unregister_compound(CompoundId id) {
    Impl& p = *impl_;
    // Unknown / stale / already-freed → safe no-op. A compound still used by a live body is refused
    // (reject-if-referenced, ADR-0028).
    if (id.index >= p.compounds.size() || p.compound_generation[id.index] != id.generation ||
        p.compound_live[id.index] == 0) {
        return false;
    }
    if (p.compound_refs[id.index] != 0) {
        return false;
    }
    // Release the compound's hold on each of its child hulls (so they become unregisterable once no
    // other reference remains) — the mirror of the increments register_compound made.
    const CompoundShape& c = p.compounds[id.index];
    for (std::size_t i = 0; i < c.child_count(); ++i) {
        const ShapeDesc& cs = c.child_shape[i];
        if (cs.type == ShapeType::ConvexHull && cs.hull.index < p.hull_refs.size() &&
            p.hull_refs[cs.hull.index] > 0) {
            --p.hull_refs[cs.hull.index];
        }
    }
    p.compound_live[id.index] = 0;
    ++p.compound_generation[id.index];
    p.compound_free_list.push_back(id.index);
    return true;
}

bool PhysicsWorld::compound_info(CompoundId id, CompoundInfo& out) const {
    const Impl& p = *impl_;
    if (id.index >= p.compounds.size() || p.compound_generation[id.index] != id.generation ||
        p.compound_live[id.index] == 0) {
        return false;
    }
    const CompoundShape& c = p.compounds[id.index];
    out.volume = c.volume;
    out.centroid = c.centroid_authored;
    out.inertia_per_mass = c.inertia_per_mass;
    out.principal_rotation = c.principal;
    out.child_count = static_cast<std::uint32_t>(c.child_count());
    return true;
}

HeightfieldId PhysicsWorld::register_heightfield(const HeightfieldDesc& desc) {
    Impl& p = *impl_;
    HeightfieldShape hf;
    if (!build_heightfield(desc, hf)) {
        return HeightfieldId{}; // null id — nothing stored on failure
    }
    std::uint32_t index;
    if (!p.heightfield_free_list.empty()) {
        index = p.heightfield_free_list.back();
        p.heightfield_free_list.pop_back();
        p.heightfields[index] = std::move(hf);
        p.heightfield_live[index] = 1;
        p.heightfield_refs[index] = 0;
    } else {
        index = static_cast<std::uint32_t>(p.heightfields.size());
        p.heightfields.push_back(std::move(hf));
        p.heightfield_generation.push_back(0);
        p.heightfield_live.push_back(1);
        p.heightfield_refs.push_back(0);
    }
    return HeightfieldId{index, p.heightfield_generation[index]};
}

bool PhysicsWorld::heightfield_info(HeightfieldId id, HeightfieldInfo& out) const {
    const Impl& p = *impl_;
    ShapeDesc s;
    s.type = ShapeType::Heightfield;
    s.heightfield = id;
    const HeightfieldShape* hf = p.heightfield_of(s);
    if (hf == nullptr) {
        return false;
    }
    out.columns = hf->columns;
    out.rows = hf->rows;
    out.triangle_count = hf->triangle_count();
    out.local_bounds = hf->local_bounds();
    return true;
}

bool PhysicsWorld::unregister_heightfield(HeightfieldId id) {
    Impl& p = *impl_;
    if (id.index >= p.heightfields.size() || p.heightfield_generation[id.index] != id.generation ||
        p.heightfield_live[id.index] == 0 || p.heightfield_refs[id.index] != 0) {
        return false; // unknown / stale / freed, or a live body still stands on it
    }
    p.heightfield_live[id.index] = 0;
    ++p.heightfield_generation[id.index];
    p.heightfields[id.index] = HeightfieldShape{}; // release the samples now, not at reuse
    p.heightfield_free_list.push_back(id.index);
    return true;
}

std::uint64_t PhysicsWorld::heightfield_query_skips() const noexcept {
    return impl_->hf_query_skips.load(std::memory_order_relaxed);
}

std::span<const ContactEvent> PhysicsWorld::contact_events() const noexcept {
    return {impl_->contact_events_front.data(), impl_->contact_events_front.size()};
}

std::span<const TriggerEvent> PhysicsWorld::trigger_events() const noexcept {
    return {impl_->trigger_events_front.data(), impl_->trigger_events_front.size()};
}

std::span<const SleepEvent> PhysicsWorld::sleep_events() const noexcept {
    return {impl_->sleep_events_front.data(), impl_->sleep_events_front.size()};
}

} // namespace rime::physics
